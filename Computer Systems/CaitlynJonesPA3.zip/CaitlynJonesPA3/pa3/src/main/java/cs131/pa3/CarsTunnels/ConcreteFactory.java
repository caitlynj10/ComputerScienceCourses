package cs131.pa3.CarsTunnels;

import cs131.pa3.Abstract.Direction;
import cs131.pa3.Abstract.Factory;
import cs131.pa3.Abstract.Tunnel;
import cs131.pa3.Abstract.Vehicle;

/**
 * The class implementing the Factory interface for creating instances of classes
 * @author cs131a
 *
 */

public class ConcreteFactory implements Factory {

    /**
     * Creates and returns a new tunnel with the given name
     */
    @Override
    public Tunnel createNewBasicTunnel(String name){
        return new BasicTunnel(name);
    }

    /**
     * Creates and returns a new car with name and direction
     */
    @Override
    public Vehicle createNewCar(String name, Direction direction){
        return new Car(name, direction);
    }

    /** 
     * Creates and returns a new sled with name and direction
     */
    @Override
    public Vehicle createNewSled(String name, Direction direction){
            return new Sled(name, direction);

        }
}

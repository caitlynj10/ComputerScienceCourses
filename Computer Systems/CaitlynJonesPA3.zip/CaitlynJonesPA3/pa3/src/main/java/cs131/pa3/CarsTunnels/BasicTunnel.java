package cs131.pa3.CarsTunnels;

import cs131.pa3.Abstract.Direction;
import cs131.pa3.Abstract.Tunnel;
import cs131.pa3.Abstract.Vehicle;

/**
 * 
 * The class for the Basic Tunnel, extending Tunnel.
 * @author cs131a
 *
 */
public class BasicTunnel extends Tunnel{

	
	private int occupancy = 0; //tracks the current occupancy of vehicles in the tunnel
	private Direction currentDirection = null; //tracks the current direction of vehicles in the tunnel
	private final int MAX_VEHICLE_OCCUPANCY = 3; //maximum number of vehicles allowed in the tunnel at once
	private boolean sledThere = false; //tracks whether a sled is currently in the tunnel
	/**
	 * Creates a new instance of a basic tunnel with the given name
	 * @param name the name of the basic tunnel
	 */
	public BasicTunnel(String name) {
		super(name);
	}

	/**
	 * This function attempts to allow a vehicle to enter the tunnel.
	 * It checks the current vehicle occupancy, direction, and type 
	 * of vehicle to determine if entry is	allowed. 
	 * @param vehicle the vehicle attempting to enter the tunnel
	 * @return true if the vehicle is allowed to enter, false otherwise
	 */
	@Override
	protected boolean tryToEnterInner(Vehicle vehicle) {
		boolean isSled = (vehicle instanceof Sled); //checks if the vehicle is an instance of a Sled
		synchronized (this){ //synchronize to make sure the thread is safe
			if(occupancy == 0){
				currentDirection = vehicle.getDirection();
				occupancy++;
				sledThere = isSled; //updates the status of the sled presence 
				return true;
			}

			if(isSled){ //if the vehicle is a sled, it cannot enter with other vehicles
				return false;
			}

			if(sledThere){ //if a sled is already in the tunnel, no other vehicles can enter
				return false;
			}

			if(vehicle.getDirection() != currentDirection){ //directions must match
				return false;
			}

			if(occupancy < MAX_VEHICLE_OCCUPANCY){ //check if the tunnel has space for more vehicles
				occupancy++;
				return true;
			}	
			return false;

		}
	}

	/**
	 * This function updates the tunnel's state when a vehicle exits.
	 * It updates the occupancy, sled presence, and direction.
	 */
	@Override
	protected void exitTunnelInner(Vehicle vehicle) {
		synchronized(this){
			if(occupancy > 0){
				occupancy--;
				if(vehicle instanceof Sled){
					sledThere = false;
				}
				if(occupancy == 0){
					currentDirection = null;
				}
			}
		}
	}
	
}

package cs131.pa1.filter.sequential;
import cs131.pa1.filter.Filter;
import cs131.pa1.filter.Message;
import java.io.File;
import java.util.LinkedList;;


public class ListFilesFilter extends SequentialFilter {
	
	@Override
	protected String processLine(String line) {
		return null;
	}

	/**
	 * This method lists all the files in the current working directory.
	 */
	@Override
	public void process(){
		//Initialize output if it is null.
		if(this.output == null){
			this.output = new LinkedList<String>();
		}

		//Get the current working directory and list its files.
		File currDirect = new File(SequentialREPL.currentWorkingDirectory);
		File [] files = currDirect.listFiles();
		if(files != null){
			for(File f : files){
				output.add(f.getName());
			}
		}
	}

	/**
	 * This method throws an error because ls does 
	 * not take any inputs.
	 */
	public void setPrevFilter(Filter prevFilter) {
		throw new IllegalArgumentException(Message.CANNOT_HAVE_INPUT.with_parameter("ls"));

	}

	/**
	 * This method always returns true because
	 * ls is done after the call the process.
	 */
	@Override
	public boolean isDone(){
		return true;
	}

}

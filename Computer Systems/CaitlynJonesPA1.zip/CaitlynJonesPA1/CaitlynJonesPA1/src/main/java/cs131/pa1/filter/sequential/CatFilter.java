package cs131.pa1.filter.sequential;
import java.io.File;
import java.util.LinkedList;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import cs131.pa1.filter.Filter;
import cs131.pa1.filter.Message;

public class CatFilter extends SequentialFilter {
	
	private String fileName;

	/**
	 * Constructor for CatFilter
	 * @param fileName
	 */
	public CatFilter(String fileName) {
		this.fileName = fileName;
	}
	@Override
	protected String processLine(String line) {
		return null;
	}
	
	/**
	 * This method reads the content of the file
	 * and stores each line in the output list.
	 * If the file does not exist/cannot be read,
	 * this method throws a RuntimeException.
	 */
	@Override
	public void process(){
		//Intialize output if it is null
		if(this.output == null){
			this.output = new LinkedList<String>();
		}
		//Get the absolute path of the file
		String filePath;
		File file = new File(fileName);
		if(file.isAbsolute()){
			filePath = fileName;
		}
		//Relative path
		else{
			filePath = SequentialREPL.currentWorkingDirectory + SequentialREPL.PATH_SEPARATOR + fileName;	
		}
		//Check if the file exists and is a file; throws error if not
		File targetFile = new File(filePath);
		if(!targetFile.exists() || !targetFile.isFile()){
			throw new RuntimeException(Message.FILE_NOT_FOUND.with_parameter("cat " +fileName));
		}
		//Read the file and store each line in output; throws error if cannot read
		try (BufferedReader reader = new BufferedReader(new FileReader(targetFile))){
			String line;
			while((line = reader.readLine()) != null){
				output.add(line);
			} 
		}
		catch (FileNotFoundException e){
			throw new RuntimeException(Message.FILE_NOT_FOUND.with_parameter("cat " + fileName));
		}
		catch (IOException e){
			throw new RuntimeException(Message.FILE_NOT_FOUND.with_parameter("cat " + fileName));
		}
	}

	/**
	 * This method throws an error if
	 * the user tries to give input to cat.
	 * @param prevFilter
	 */
	@Override
	public void setPrevFilter(Filter prevFilter){
		throw new IllegalArgumentException(Message.CANNOT_HAVE_INPUT.with_parameter("cat " + fileName));
	}

	/**
	 * This method always returns true
	 * because cat is always done after.
	 */
	@Override
	public boolean isDone(){
		return true;
	}
}

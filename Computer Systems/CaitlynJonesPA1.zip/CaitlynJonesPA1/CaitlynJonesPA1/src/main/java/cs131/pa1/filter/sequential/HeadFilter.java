package cs131.pa1.filter.sequential;

public class HeadFilter extends SequentialFilter {

	private int lineLimit;
	private int linesProcessed = 0;

	/**
	 * Constructor for HeadFilter
	 * @param lineLimit
	 */
	public HeadFilter(String lineLimit){
		//Converts the line from string to integer
		this.lineLimit = Integer.parseInt(lineLimit);
		this.linesProcessed = 0;
	}
	
	/**
	 * Processes a line and returns it if the
	 * number of lines processed is less than
	 * the given line limit.
	 * @param line
	 * @return null
	 */
	@Override
	protected String processLine(String line) {
		if(linesProcessed < lineLimit){
			linesProcessed++;
			return line;
		}
		else{
			return null;
		}
	}

	/**
	 * Ends the filter if the number of lines is greater than
	 * the line limit or if the super class is done.
	 */
	@Override
	public boolean isDone(){
		return linesProcessed >= lineLimit || super.isDone();
	}
	
}

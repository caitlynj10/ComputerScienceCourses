package cs131.pa1.filter.sequential;
import java.util.HashSet;
import java.util.Set;
public class UniqFilter extends SequentialFilter {
	
	//Set to keep track of the lines already viewed
	private Set<String> linesViewed = new HashSet<>();;
	
	/**
	 * This method processes a line by adding it to a set
	 * if if not has been viewed. 
	 * @param line
	 */
	@Override
	protected String processLine(String line) {
		//If the line has been viewed, return null
		if(linesViewed.contains(line)){
			return null;
		}
		//Add the the line to the set and return it
		linesViewed.add(line);
		return line;
	}

}

package cs131.pa1.filter.sequential;

public class GrepFilter extends SequentialFilter {

	private String pattern;

	/**
	 * Constructor for GrepFilter
	 * @param pattern
	 */
	public GrepFilter(String pattern){
		this.pattern = pattern;
	}
	

	/**
	 * This method processes the given line and 
	 * returns the line if it contains the pattern.
	 * @param line
	 * @return the line if it contains the pattern, null otherwise
	 */
	@Override
	protected String processLine(String line) {
		if (line.contains(pattern)){
			return line;
		}
		else{
			return null;
		}
	}

}

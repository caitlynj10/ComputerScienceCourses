package cs131.pa1.filter.sequential;
import java.util.LinkedList;

public class WordCountFilter extends SequentialFilter {

	//Variables to track line, word, and character count
	private int lineCount = 0;
	private int wordCount = 0;
	private int charCount = 0;

	/**
	 * This method process a line by updating the line, word, 
	 * and character counts.
	 * @param line
	 */
	@Override
	protected String processLine(String line) {
		//Updates counts
		lineCount++;
		charCount += line.length();

		//If the line is not empty, split into words and count them
		if(!line.trim().isEmpty()){
			String[] words = line.trim().split("\\s+");
			wordCount += words.length;
		}
		return null;
	}

	/**
	 * This method processes all input lines and then adds a single
	 * output line with the line, word, and character counts.
	 */
	@Override
	public void process(){
		//Initialize if null output
		if(this.output == null){
			this.output = new LinkedList<String>();
		}

		//Reset counts BEFORE processing
		lineCount = 0;
		wordCount = 0;
		charCount = 0;
		//Call superclass process
		super.process();

		//Initialize result string and add to the output
		String result = lineCount + " " + wordCount + " " + charCount;
		output.add(result);
	}
	
}

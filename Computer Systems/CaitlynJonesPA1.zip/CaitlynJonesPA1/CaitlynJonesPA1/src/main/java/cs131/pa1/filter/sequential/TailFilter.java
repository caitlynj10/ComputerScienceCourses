package cs131.pa1.filter.sequential;
import java.util.LinkedList;
import java.util.Queue;

public class TailFilter extends SequentialFilter {

	//The number of lines to be stored in the buffer
	private int lineLimit;
	private Queue<String> buffer;

	/**
	 * Constructor for TailFilter
	 * @param lineLimit
	 */
	public TailFilter(String lineLimit){
		//Need to convert lineLimit string into an integer
		this.lineLimit = Integer.parseInt(lineLimit);
		this.buffer = new LinkedList<String>();
	}
	
	/**
	 * This method processes each line by adding it to a buffer.
	 * @param line
	 */
	@Override
	protected String processLine(String line) {
		buffer.add(line);
		//If the buffer exceeds the line limit, it removes the oldest line.
		if(buffer.size() > lineLimit){
			buffer.poll();
		}
		return null;
	}

	/**
	 * This method processes the input by calling the super
	 * process method. Then it adds all the lines in the buffer
	 * to the output.
	 */
	@Override
	public void process(){
		//Initialize output if it is null
		if (this.output == null){
			this.output = new LinkedList<String>();
		}

		//Calling superclass process method
		super.process();

		//While the buffer is not empty, it adds each line to the output.
		while(!buffer.isEmpty()){
			output.add(buffer.poll());
		}
	}
	
}

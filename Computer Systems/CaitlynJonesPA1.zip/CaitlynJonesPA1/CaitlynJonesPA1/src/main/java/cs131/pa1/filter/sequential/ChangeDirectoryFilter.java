package cs131.pa1.filter.sequential;
import java.io.File;
import cs131.pa1.filter.Filter;
import cs131.pa1.filter.Message;

public class ChangeDirectoryFilter extends SequentialFilter {
	
	private String directoryName;
	/**
	 * Constructor for ChangeDirectoryFilter
	 * @param directoryName
	 */
	public ChangeDirectoryFilter(String directoryName){
		this.directoryName = directoryName;
	}


	/**
	 * Processes a line to change the current working
	 * directory in SequentialREPL. Throws errors
	 * if the directory does not exist/command is invalid.
	 * @param line
	 * @return null
	 */
	@Override
	protected String processLine(String line) {
		String newPath;
		//Checks for . (current directory)
		if(directoryName.equals(".")){
			return null;
		}
		//Handles the cases for parent directory (..)
		else if(directoryName.equals("..")){
			File currentD = new File(SequentialREPL.currentWorkingDirectory);
			File parentD = currentD.getParentFile();
			if(parentD != null){
				newPath = parentD.getAbsolutePath();
			}
			else{
				return null;
			}
		}
		//Checks for absolute paths
		else{
			newPath = SequentialREPL.currentWorkingDirectory + SequentialREPL.PATH_SEPARATOR + directoryName;
		}
		
		//Checks is target directory exists and is a directory
		File targetD = new File(newPath);
		if(targetD.exists() && targetD.isDirectory()){
			SequentialREPL.currentWorkingDirectory = targetD.getAbsolutePath();
			return null;
		}
		//throws error if it's not found
		else{
			throw new RuntimeException(Message.DIRECTORY_NOT_FOUND.with_parameter("cd " + directoryName));
		}
	}

	/**
	 * This method throws an error since
	 * cd cannot have an input.
	 * @param prevFilter
	 */
	@Override
	public void setPrevFilter(Filter prevFilter) {
		throw new IllegalArgumentException(Message.CANNOT_HAVE_INPUT.with_parameter("cd " + directoryName));
	}

	/**
	 * This method throws an error since
	 * cd cannot have an output.
	 * @param nextFilter
	 */
	@Override
	public void setNextFilter(Filter nextFilter) {
		throw new IllegalArgumentException(Message.CANNOT_HAVE_OUTPUT.with_parameter("cd " + directoryName));
	}

	
}

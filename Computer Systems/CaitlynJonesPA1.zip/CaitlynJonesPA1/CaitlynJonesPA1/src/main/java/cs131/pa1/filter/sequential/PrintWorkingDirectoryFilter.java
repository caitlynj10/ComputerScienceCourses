package cs131.pa1.filter.sequential;
import cs131.pa1.filter.Message;
import cs131.pa1.filter.Filter;

public class PrintWorkingDirectoryFilter extends SequentialFilter {
	/**
	 * This method returns the current working directory.
	 */
	@Override
	protected String processLine(String line) {
		
		return SequentialREPL.currentWorkingDirectory;
	}

	/**
	 * This method throws an error because pwd
	 * does not take any inputs.
	 */
	@Override
	public void setPrevFilter(Filter prevFilter){
		throw new IllegalArgumentException(Message.CANNOT_HAVE_INPUT.with_parameter("pwd"));	
	}
	
}

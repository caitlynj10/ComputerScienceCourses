package cs131.pa1.filter.sequential;
import java.io.File;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.IOException;
import cs131.pa1.filter.Message;
import cs131.pa1.filter.Filter;
public class RedirectFilter extends SequentialFilter {
	private String fileName;

	/**
	 * Constructor for RedirectFilter
	 * @param fileName
	 */
	public RedirectFilter(String fileName){
		this.fileName = fileName;
	}
	
	@Override
	protected String processLine(String line) {
		return null;
	}

	/**
	 * This method writes the contents of the input queue to a file.
	 */
	@Override
	public void process(){
		//Define the file path
		String filePath;
		File file = new File(fileName);
		//Check if the file path is absolute or relative
		if(file.isAbsolute()){
			filePath = fileName;

		}
		//If the file path is relative, append the current working directory
		else{
			filePath = SequentialREPL.currentWorkingDirectory + SequentialREPL.PATH_SEPARATOR + fileName;
		}

		//Write the contents of the input to the file
		try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))){
			//Write each line from the input to the file while there are still lines in the input
			while(!input.isEmpty()){
				String line = input.poll();
				writer.write(line);
				writer.newLine();

			}
		}
		//Throw error if there is an issue writing to the file
		catch (IOException e){
			throw new RuntimeException("Error writing to file: " + fileName);

		}
		
	}

	/**
	 * This method throws an error because > cannot have an output filter.
	 */
	@Override
	public void setNextFilter(Filter nextFilter){
		throw new IllegalArgumentException(Message.CANNOT_HAVE_OUTPUT.with_parameter("> " + fileName));
	}
	
}

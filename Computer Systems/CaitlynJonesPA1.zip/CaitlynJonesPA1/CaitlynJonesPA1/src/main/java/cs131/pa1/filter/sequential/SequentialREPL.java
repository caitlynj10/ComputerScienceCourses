package cs131.pa1.filter.sequential;
import java.util.Scanner;
import java.util.List;
import java.util.LinkedList;
import cs131.pa1.filter.Message;


/**
 * The main implementation of the REPL (read-eval-print-loop). It reads
 * commands from the user, parses them, executes them and displays the result.
 * 
 * @author cs131a
 *
 */
public class SequentialREPL {
	
	/**
	 * The path of the current working directory
	 */
	public static String currentWorkingDirectory;
	public static final String PATH_SEPARATOR = System.getProperty("file.separator");

	/**
	 * The main method that will execute the REPL loop
	 * 
	 * @param args not used
	 */
	public static void main(String[] args) {
		currentWorkingDirectory = System.getProperty("user.dir"); //Initialize current working directory
		Scanner scanner = new Scanner(System.in); //Reading user input
		System.out.print(Message.WELCOME);
		//REPL loop
		while(true){
			System.out.print(Message.NEWCOMMAND);
			String userInput = scanner.nextLine();
			//Checking for exit command
			if(userInput.trim().equals("exit")) { 
				break;
			}

			List<SequentialFilter> filters = SequentialCommandBuilder.createFiltersFromCommand(userInput);
			//If there are filters, process them
			if(filters != null && !filters.isEmpty()){
				//Start with the first filter
				try{
					SequentialFilter firstFilter = filters.get(0);
					//If there is no input, initialize the input queue
					if(firstFilter.input == null){
						firstFilter.input = new LinkedList<String>();
					}
					//The following comands cannot have piped input-->add empty inputs
					if(firstFilter instanceof PrintWorkingDirectoryFilter ||
						firstFilter instanceof ListFilesFilter ||
						firstFilter instanceof CatFilter ||
						firstFilter instanceof ChangeDirectoryFilter){
							firstFilter.input.add("");
					}

					//Process each filter in the list
					for(SequentialFilter filter : filters){ 
						filter.process();
					}

				}
				//Catch any errors and print their error messages
				catch (Exception e){ 
					System.out.print(e.getMessage());
				}
			}
		} 
			//Exit message and close input scanner
			System.out.print(Message.GOODBYE);
			scanner.close();
	}

}

package cs131.pa1.filter.sequential;

public class PrintFilter extends SequentialFilter {
	
	/**
	 * This method prints the line to the console.
	 */
	@Override
	protected String processLine(String line) {
		System.out.println(line);
		return null;
	}

}

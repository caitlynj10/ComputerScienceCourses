package cs131.pa2.filter.concurrent;

import cs131.pa2.filter.Message;
import java.util.Scanner;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

/**
 * The main implementation of the REPL (read-eval-print-loop). It reads
 * commands from the user, parses them, executes them and displays the result.
 * 
 * @author cs131a
 *
 */
public class ConcurrentREPL {
	
	/**
	 * The path of the current working directory
	 */
	public static String currentWorkingDirectory;
	public static final String PATH_SEPARATOR = System.getProperty("file.separator");

	/**
	 * Inner class to help with background jobs. Contains
	 * job ID, command string, and the list of threads associated
	 * with the job.
	 */
	private static class Jobs{
		final int ID;
		final String COMMAND;
		final List<Thread> THREADS;

		// Constructs a new job
		Jobs(int ID, String COMMAND, List<Thread> THREADS){
			this.ID = ID;
			this.COMMAND = COMMAND;
			this.THREADS = THREADS;
		}

		// Check if the job is alive, i.e., running and non-interrupted threads
		boolean isAlive(){
			for(Thread t : THREADS){
				if(t.isAlive() && !t.isInterrupted()){
					return true;
				}
			}
			return false;	
		}


		//Variables to keep track of all jobs and next job ID
		private static final List<Jobs> jobsList = new ArrayList<>();
		private static int nextID = 1;
		
	
		// Resets the job state by interrupting all jobs and clearing
		// the job list
		private static void resetState() {
			
			for (Jobs job : jobsList) {
				for (Thread t : job.THREADS) {
					t.interrupt();
				}
			}
			jobsList.clear();
			nextID = 1;
		}
	}
	/**
	 * The main method that will execute the REPL loop
	 * 
	 * @param args not used
	 */
	public static void main(String[] args) {
		currentWorkingDirectory = System.getProperty("user.dir");
		
		// Reset job state at the beginning of each REPL session
		Jobs.resetState();

		Scanner consoleReader = new Scanner(System.in);
		System.out.print(Message.WELCOME);

		while (true) {

			cleanJobs();

			System.out.print(Message.NEWCOMMAND);
			
			// Read user command. If it's just whitespace, skip to next command
			String userInput = consoleReader.nextLine().trim();
			if (userInput.isEmpty()) {
				continue;
			}
			// Exit the REPL if the command is "exit".
			if (userInput.equals("exit")) {
				break;
			}

			//Prints all background jobs
			if (userInput.equals("repl_jobs")) {
				printJobs();
				continue;
			}

			//Kills a background job based on job ID
			if(userInput.startsWith("kill")){
				String [] tokens = userInput.split("\\s+");
				if(tokens.length != 2){
					System.out.print("Invalid argument: " + userInput);
					continue;	
				}
				try{
					int jobID = Integer.parseInt(tokens[1]);
					killJob(jobID);
				}
				catch(NumberFormatException e){
					System.out.print("Invalid argument: " + userInput);
				}
				continue;
			}

			// Check if the command should be run in the background
			boolean background = false;
			String oldCommand = userInput;
			if(userInput.endsWith("&")){
				background = true;
				userInput = userInput.substring(0, userInput.length() - 1).trim();
			}
			List<ConcurrentFilter> filters = ConcurrentCommandBuilder.createFiltersFromCommand(userInput);
			if(filters == null){
				continue;
			}			
			List<Thread> threads = new ArrayList<>();
			for(ConcurrentFilter filter : filters){
				Thread t = new Thread(filter);
				threads.add(t);
			}

			for(Thread t : threads){
				t.start();
			}
			if(background){
				int ID = Jobs.nextID++;
				String commandJob = oldCommand.endsWith("&") ?
					oldCommand.substring(0, oldCommand.length() -1).trim() : oldCommand;
				Jobs job = new Jobs(ID, commandJob, threads);
				Jobs.jobsList.add(job);

			}
			else{
				for(Thread t : threads){
					try{
						t.join(); // Wait for each thread to complete
					}
					catch(InterruptedException e){
						Thread.currentThread().interrupt();
					}
				}
			}
		}
		
		// Clean up any remaining background jobs before exiting
		Jobs.resetState();
		
		System.out.print(Message.GOODBYE);
		consoleReader.close();
	}


	/**
	 * This method prints all currently running background jobs
	 */
	private static void printJobs(){
		cleanJobs();
		for(Jobs job : Jobs.jobsList){
			if(job.isAlive()){
				System.out.print("\t" + job.ID + ". " + job.COMMAND + " &\n");
			}
		}
	}

	/**
	 * This method removes all completed jobs from the jobs list.
	 */
	private static void cleanJobs(){
		Jobs.jobsList.removeIf(job -> !job.isAlive());
	}

	/**
	 * This method kills a background job based on its ID
	 * @param id
	 */
	private static void killJob(int id){
		Iterator<Jobs> IT = Jobs.jobsList.iterator();
		boolean found = false;
		while(IT.hasNext()){
			Jobs job = IT.next();
			if(job.ID == id){
				found = true;
				for(Thread t : job.THREADS){
					t.interrupt();
				}

				IT.remove();
				break;
			}
		}
		if( !found){
			System.out.print("No such job: " + id);
		}
	}

}

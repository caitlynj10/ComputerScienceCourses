package cs131.pa2.filter.concurrent;

import cs131.pa2.filter.Filter;
import cs131.pa2.filter.Message;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * A filter that takes a file name as a parameter and outputs the lines of that
 * file. This filter cannot have input.
 * 
 * @author cs131a
 *
 */
public class CatFilter extends ConcurrentFilter {

	private String fileName;

	/**
	 * Constructs a filter to read and output the lines of the given file.
	 * 
	 * @param fileName the name of the file that will be read
	 */
	public CatFilter(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * This method reads the lines of the file and adds them to the output.
	 * @throws IllegalArgumentException if the file does not exist
	 */
	@Override
	public void process() throws IllegalArgumentException {
		try {
			Scanner fileReader = new Scanner(
				new File(ConcurrentREPL.currentWorkingDirectory + ConcurrentREPL.PATH_SEPARATOR + fileName));
			// Read lines from file and add them to output.
			while (fileReader.hasNextLine()) {
				if(output != null){
					try{
						output.put(fileReader.nextLine()); // Use put() for proper blocking behavior
					}
					catch (InterruptedException e){
						Thread.currentThread().interrupt();
						break;
					}
				}
			}
			fileReader.close();
			// Forward poison to signal end of pipeline for successful completion
			try{
				forwardPoison();
			}
			catch(InterruptedException e){
				Thread.currentThread().interrupt();
			}
		} 
		catch (FileNotFoundException e) {
			// When there's an error, don't forward poison - let the exception terminate the pipeline
			throw new IllegalArgumentException(Message.FILE_NOT_FOUND.with_parameter("cat " + fileName));
		}
	}

	@Override
	protected String processLine(String line) {
		return null;
	}

	/**
	 * @throws IllegalArgumentException if the previous filter is not null since
	 *                                  CatFilter cannot have input
	 */
	@Override
	public void setPrevFilter(Filter prevFilter) throws IllegalArgumentException {
		if (prevFilter != null) {
			throw new IllegalArgumentException(Message.CANNOT_HAVE_INPUT.with_parameter("cat " + fileName));
		}
	}
}

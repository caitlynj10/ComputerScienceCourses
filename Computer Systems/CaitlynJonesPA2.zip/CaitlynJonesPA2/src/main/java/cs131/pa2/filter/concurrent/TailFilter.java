package cs131.pa2.filter.concurrent;

import java.util.ArrayList;
import java.util.List;


/**
 * A filter that outputs the last n lines of its input, where n is specified in
 * construction. This filter requires input.
 * 
 * @author cs131a
 *
 */
public class TailFilter extends ConcurrentFilter {
	
	private int numLines;
	private List<String> lines;
	
	/**
	 * Constructs a filter to return the last given number of lines of input.
	 * 
	 * @param numLines the number of lines that the filter will output
	 */
	public TailFilter(String numLines) {
		this.numLines = Integer.valueOf(numLines);
		this.lines = new ArrayList<>();
	}
	
	/**
	 * Returns the given line if it is within the last n lines of input, where
	 * n is the number of lines passed as a parameter to the constructor.
	 */
	@Override
	public String processLine(String line) {
		if (input.size() >= numLines) {
			return null;
		}
		return line;
	}

	//add comments
	@Override
	public void process(){
		try{
			if(input != null){
				while(true){
					String line = input.take();
					if(POISON.equals(line)){
						break;
					}
					lines.add(line);
				}
			}

			int allLines = lines.size();
			int start = Math.max(0, allLines - numLines);

			for(int i = start; i< allLines; i++){
				if(output != null){
					output.put(lines.get(i));
				}
			}

			forwardPoison();
		}
		catch(InterruptedException e){
			Thread.currentThread().interrupt();
			try{
				forwardPoison();
			}
			catch(InterruptedException ex){
				Thread.currentThread().interrupt();
			}
		}
	}
}

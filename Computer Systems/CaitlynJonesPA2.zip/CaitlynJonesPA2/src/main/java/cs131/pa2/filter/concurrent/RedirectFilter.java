package cs131.pa2.filter.concurrent;

import java.io.PrintStream;
import java.io.FileNotFoundException;

import cs131.pa2.filter.Filter;
import cs131.pa2.filter.Message;

/**
 * A filter that writes each line of input to a file. If the given file does not exist, the 
 * file will be created. This filter requires input and cannot have output.
 * 
 * @author cs131a
 *
 */
public class RedirectFilter extends ConcurrentFilter {
	
	private String fileName;
	private PrintStream outputFile;
	
	public RedirectFilter(String fileName) {
		this.fileName = fileName;
	}
	
	/**
	 * Constructs a RedirectFilter to write to the specified file.
	 */
	
	@Override
	public void process() {
		try {
			outputFile = new PrintStream(ConcurrentREPL.currentWorkingDirectory + ConcurrentREPL.PATH_SEPARATOR + fileName);
			
			if(input != null) {
				while (true) {
					String line = input.take(); 
					if(POISON.equals(line)) {
						break;
					}
					processLine(line);
				}
			}
		} 
		catch(FileNotFoundException e) {
			// Do nothing.
		}
		catch(InterruptedException e) {
			Thread.currentThread().interrupt();
		}
		finally{
			if(outputFile != null){
				outputFile.close();
			}
		}
	}
	
	@Override
	protected String processLine(String line) {
		if(outputFile != null){
			outputFile.println(line);
		}
		return null;
	}
	
	/**
	 * @throws IllegalArgumentException if next filter is not null since
	 *                                  RedirectFilter cannot have output
	 */
	@Override
	public void setNextFilter(Filter nextFilter) throws IllegalArgumentException {
		if (nextFilter != null) {
			throw new IllegalArgumentException(Message.CANNOT_HAVE_OUTPUT.with_parameter("> " + fileName));
		}
	}
	
}

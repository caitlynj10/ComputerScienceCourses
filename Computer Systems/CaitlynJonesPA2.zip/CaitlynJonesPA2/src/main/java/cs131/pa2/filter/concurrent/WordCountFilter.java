package cs131.pa2.filter.concurrent;

/**
 * A filter that outputs the number of lines, words, and characters that are
 * inputed. This filter requires input.
 * 
 * @author cs131a
 *
 */
public class WordCountFilter extends ConcurrentFilter {

	// Variables to keep track of line, word, and character counts
	private int lineCount;
	private int wordCount;
	private int charCount;

	/**
	 * Processes the input and counts lines, words, and characters.
	 * Forwards the appropriate poison pill based on whether an error
	 * was encountered in the pipeline.
	 */
	@Override
	public void process() {
		try{
			boolean receivedInput = false;
			boolean isErrorCase = false;
			
			if(input != null){
				while(true){
					String line = input.take();
					if(POISON.equals(line)){
						// Normal completion - output counts even if no input (empty file case)
						break;
					}
					if(ERROR_POISON.equals(line)){
						// Pipeline error - don't output counts
						isErrorCase = true;
						break;
					}
					receivedInput = true;
					processLine(line);
				}
			}
			
			// Only output counts if this is not an error case
			if(output != null && !isErrorCase){
				output.put(lineCount + " " + wordCount + " " + charCount);
			}
			
			// Forward the appropriate poison type
			if(isErrorCase){
				forwardErrorPoison();
			} else {
				forwardPoison();
			}
		}
		catch(InterruptedException e){
			Thread.currentThread().interrupt();
			try{
				forwardPoison();
			}
			catch(InterruptedException ex){
				Thread.currentThread().interrupt();
			}
		}
	}

	/**
	 * Increases the counts and returns null.
	 */
	@Override
	protected String processLine(String line) {
		lineCount++;
		if(!line.trim().isEmpty()){
			wordCount += line.split("\\s+").length;
		}
		charCount += line.length();
		return null;
	}

}

package cs131.pa2.filter.concurrent;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.BlockingQueue;

import cs131.pa2.filter.Filter;

/**
 * An abstract class that extends the Filter and implements the basic functionality of all filters. Each filter should
 * extend this class and implement functionality that is specific for this filter. 
 * You should not modify this class
 * .
 * @author cs131a
 *
 */
public abstract class ConcurrentFilter extends Filter implements Runnable {
	/**
	 * The input queue for this filter
	 */
	protected BlockingQueue<String> input;
	/**
	 * The output queue for this filter
	 */
	protected BlockingQueue<String> output;
	
	/**
	 * String to use to tell next filter that there will be no more input.
	 */
	protected final String POISON = "POISON PILL asdfasdfasdf";
	
	/**
	 * Added this string to differentiate between normal poison and error poison
	 */
	protected final String ERROR_POISON = "ERROR POISON PILL qwerqwerqwer";

	/**
	 * Constructor for the ConcurrentFilter class. 
	 * Initializes the input and output queues to null.
	 */
	public ConcurrentFilter(){
		this.input = null;
		this.output = null;
	}

	@Override
	public void setPrevFilter(Filter prevFilter) {
		prevFilter.setNextFilter(this);
	}
	
	@Override
	public void setNextFilter(Filter nextFilter) {
		if (nextFilter instanceof ConcurrentFilter){
			ConcurrentFilter sequentialNext = (ConcurrentFilter) nextFilter;
			this.next = sequentialNext;
			sequentialNext.prev = this;
			if (this.output == null){
				this.output = new LinkedBlockingQueue<String>();
			}
			sequentialNext.input = this.output;
		} else {
			throw new RuntimeException("Should not attempt to link dissimilar filter types.");
		}
	}
	/**
	 * Process method--takes lines from the input queue, processes 
	 * them using processLine() and puts the processed 
	 * lines into the output queue. It also handles the 
	 * poison pill to signal the end of input.
	 */
	public void process(){
		try{
			if(input == null){
				forwardPoison();
				return;
			}
			while (true){
				String line = input.take(); 
				if(POISON.equals(line)){
					forwardPoison();
					break;	
				}
				if(ERROR_POISON.equals(line)){
					forwardErrorPoison();
					break;
				}
				String processedLine = processLine(line);
				if (processedLine != null && output != null){
					output.add(processedLine);
				}
			}
		}
		catch(InterruptedException e){
			Thread.currentThread().interrupt();
			try {
				forwardPoison();
			}
			catch(InterruptedException ex) {
				Thread.currentThread().interrupt();
			}
		}

	}	
	
	// Forwards the poison pill to the next filter
	protected void forwardPoison() throws InterruptedException {
		if (output != null){
			output.put(POISON);
		}
	}
	
	// Forwards the error poison pill to the next filter
	protected void forwardErrorPoison() throws InterruptedException {
		if (output != null){
			output.put(ERROR_POISON);
		}
	}
	
	@Override
	public boolean isDone() {
		return input.size() == 0;
	}

	
	/**
	 * Runs the filter in its own thread by calling 
	 * the process() method. Throws an exception if
	 * any error occurs during processing.
	 */
	public void run(){
		try{
			process();
		}
		catch(IllegalArgumentException e){
			// Print the error message to the console instead of crashing the thread
			System.out.print(e.getMessage());
			// Forward error poison to signal pipeline failure
			try {
				forwardErrorPoison();
			} catch (InterruptedException ie) {
				Thread.currentThread().interrupt();
			}
		}
	}
	
	/**
	 * Called by the {@link #process()} method for every encountered line in the input queue.
	 * It then performs the processing specific for each filter and returns the result.
	 * Each filter inheriting from this class must implement its own version of processLine() to
	 * take care of the filter-specific processing.
	 * @param line the line got from the input queue
	 * @return the line after the filter-specific processing
	 */
	protected abstract String processLine(String line);
	
}

struct Scheduler {
  pthread_cond_t lock_cv;
  pthread_mutex_t lock;

  size_t priority_counts[Priority_COUNT];
 
  /** An array that can be indexed by `Vehicle.id`, giving the associated tunnel index in the `tunnels` array. Use the
   * helper method `scheduler_get_tunnel`.
   */
  size_t *vehicle_id_to_tunnel_idx;
  size_t vehicle_count;
  struct Tunnel *tunnels;
  size_t tunnel_count;
};


/** Allocates a `struct Scheduler`. Caller must deallocate using `scheduler_destroy`. */
struct Scheduler *scheduler_create(
  const size_t vehicle_count,
  struct Tunnel *tunnels,
  const size_t tunnel_count
) 

/**
 * This function creates a new scheduler that will 
 * manage vehicle access to tunnels.
 */
{ 
  // TODO
  struct Scheduler *scheduler = malloc(sizeof(struct Scheduler)); // allocate memory for scheduler
  if(scheduler == NULL){  // check if allocation was successful
    perror("Failed to allocate scheduler");
    exit(EXIT_FAILURE);
  }
  scheduler->vehicle_id_to_tunnel_idx = malloc(sizeof(size_t) * vehicle_count); // allocate memory for vehicle to tunnel mapping  
  if(scheduler->vehicle_id_to_tunnel_idx == NULL){ // check if allocation was successful
    perror("Failed to allocate vehicle to tunnel mapping");
    exit(EXIT_FAILURE);
  }

  pthread_mutex_init(&scheduler->lock, NULL); // initialize mutex lock
  pthread_cond_init(&scheduler->lock_cv, NULL); // initialize condition variable

  for(size_t i = 0; i<Priority_COUNT; i++){
    scheduler->priority_counts[i] = 0; // initialize priority counts to 0
  }

  scheduler->vehicle_count = vehicle_count; // set vehicle count
  scheduler->tunnels = tunnels; // set tunnels
  scheduler->tunnel_count = tunnel_count; // set tunnel count

  return scheduler; // return the created scheduler
}

/** Deallocates a `struct Scheduler`. */
/**
 * This function destroys the scheduler 
 * and frees memory.
 */
void scheduler_destroy(struct Scheduler *scheduler) {
  // TODO
  pthread_cond_destroy(&scheduler->lock_cv); // destroy condition variable
  pthread_mutex_destroy(&scheduler->lock); // destroy mutex lock
  free(scheduler->vehicle_id_to_tunnel_idx); // free vehicle to tunnel mapping
  free(scheduler); // free scheduler
}

/** Returns the priority of the highest priority waiting vehicle. */
/**
 * This function iterates through the prirority counts
 * and returns the higher priority that has waiting vehicles.
 */
enum Priority scheduler_highest_waiting_priority(const struct Scheduler *scheduler) {
  // `Priority_0` is _higher_ priority than `Priority_4`. Also remember that enum members are integers, so
  // ```c
  // for (size_t i = Priority_0; i < Priority_COUNT; i++) { ... }
  // ```
  // is valid c.

  // TODO
  for (size_t i = Priority_0; i < Priority_COUNT; i++) { // iterate through priorities
    if (scheduler->priority_counts[i] > 0) { // check if there are vehicles waiting at this priority
      return i; // return the highest priority with waiting vehicles
    }
  }
  return Priority_COUNT; // return Priority_COUNT if no vehicles are waiting
}

/** Get the associated `struct Tunnel` for a given vehicle. */
struct Tunnel *scheduler_get_tunnel(const struct Scheduler *scheduler, const size_t vehicle_id) {
  const size_t tunnel_id = scheduler->vehicle_id_to_tunnel_idx[vehicle_id];
  struct Tunnel *tunnel = &scheduler->tunnels[tunnel_id];
  return tunnel;
}

/**
 * This function admits a vehicle into the tunnel
 * based on its priority and the tunnel's availability.
 */
struct Tunnel *scheduler_admit(struct Scheduler *scheduler, const struct Vehicle *vehicle) {
  // TODO
  pthread_mutex_lock(&scheduler->lock); // lock the scheduler mutex
  scheduler->priority_counts[vehicle->priority]++; // increment the count of waiting vehicles at this priority
  struct Tunnel *tunnel = NULL; // initialize tunnel pointer

  while (tunnel == NULL) {
    if (scheduler_highest_waiting_priority(scheduler) == vehicle->priority) { // check if the vehicle has the highest priority
      for (size_t i = 0; i < scheduler->tunnel_count; i++) {// iterate through tunnels
        if (tunnel_try_to_enter(&scheduler->tunnels[i], vehicle)) {// try to enter the tunnel
          tunnel = &scheduler->tunnels[i]; // set the tunnel pointer
          scheduler->vehicle_id_to_tunnel_idx[vehicle->id] = i; // map vehicle to tunnel
          break;
        }
      }
    }    
    if (tunnel == NULL) { // if no tunnel was found
      pthread_cond_wait(&scheduler->lock_cv, &scheduler->lock); // wait for a signal
    }
  }

  scheduler->priority_counts[vehicle->priority]--; // decrement the count of waiting vehicles at this priority
  pthread_mutex_unlock(&scheduler->lock); // unlock the scheduler mutex
  
  return tunnel; // return the admitted tunnel
}

/**
 * This function exits a vehicle from the tunnel and
 * notifies waiting vehicles when its done.
 */
void scheduler_exit(struct Scheduler *scheduler, const struct Vehicle *vehicle) {
  // TODO
  pthread_mutex_lock(&scheduler->lock); // lock the scheduler mutex
  struct Tunnel *tunnel = scheduler_get_tunnel(scheduler, vehicle->id); // get the tunnel associated with the vehicle
  tunnel->num_vehicles--;// decrement the number of vehicles in the tunnel
  pthread_cond_broadcast(&scheduler->lock_cv);// signal all waiting vehicles
  pthread_mutex_unlock(&scheduler->lock);// unlock the scheduler mutex
}


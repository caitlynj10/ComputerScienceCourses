struct ThreadData {
    pthread_t thread_id;
    struct Vehicle *vehicle;
    struct Scheduler *scheduler;
};

/** Allocates an array of `struct ThreadData`s. Caller must deallocate using `thread_datas_destroy`. */
struct ThreadData *thread_datas_create(const size_t count, struct Scheduler *scheduler, struct Vehicle *vehicles) {
    struct ThreadData *data = malloc(sizeof(struct ThreadData) * count);
    if (data == NULL) {
        perror("Failed to allocate thread data");
        exit(EXIT_FAILURE);
    }
    for (size_t i = 0; i < count; i++) {
        data[i].scheduler = scheduler;
        data[i].vehicle = &vehicles[i];
    }
    return data;
}

/** Deallocates an array of `struct ThreadData`s. */
void thread_datas_destroy(struct ThreadData *thread_datas) {
    free(thread_datas);
}

/**
 * This function creates a new thread that will run
 * the given run function with the given thread data.
 */
void thread_create(struct ThreadData *thread_data, void *(run)(void*)) {
    // TODO
    pthread_create(&thread_data->thread_id, NULL, run, thread_data);
}
void thread_join(const pthread_t thread_id) {
    // TODO
    pthread_join(thread_id, NULL);
}

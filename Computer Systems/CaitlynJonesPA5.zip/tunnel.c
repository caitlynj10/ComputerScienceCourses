struct Tunnel {
    size_t id;
    size_t num_vehicles;
    enum VehicleType vehicle_type;
    enum Direction direction;
}; 

/** Allocates an array of `count` `struct Tunnel`s. Caller must deallocate using `tunnels_destroy`. */
struct Tunnel *tunnels_create(const size_t count) {
    struct Tunnel *tunnels = calloc(count, sizeof(struct Tunnel));
    if (tunnels == NULL) {
        perror("Failed to allocate tunnel array");
        exit(EXIT_FAILURE);
    }

    for (size_t i = 0; i < count; ++i) {
        tunnels[i].id = i;
    }

    return tunnels;
}

/** Deallocates an array of `struct Tunnel`s. */
void tunnels_destroy(struct Tunnel *tunnels) {
    free(tunnels);
}
    /**
     * This function attempt to let a vehicle enter the tunnel.
     * If the vehicle can enter, the function updates the tunnel state
     * and returns true. Otherwise, it returns false.
     */
    bool tunnel_try_to_enter(struct Tunnel *tunnel, const struct Vehicle *vehicle) {
    // TODO
    if (tunnel->num_vehicles == 0) { // if the tunnel is empty
        tunnel->vehicle_type = vehicle->type; // set the tunnel's vehicle type 
        tunnel->direction = vehicle->direction; //set the tunnel's direction
        tunnel->num_vehicles = 1;// increment the number of vehicles in the tunnel
        return true;
    } 
    if (tunnel->vehicle_type == vehicle->type && tunnel->direction == vehicle->direction && tunnel->num_vehicles < vehicle_type_to_capacity[vehicle->type]) {
        // if the vehicle type and direction match and the tunnel is not full
        tunnel->num_vehicles++; // increment the number of vehicles in the tunnel
        return true;
    } 
    
    return false; // otherwise, the vehicle cannot enter

}

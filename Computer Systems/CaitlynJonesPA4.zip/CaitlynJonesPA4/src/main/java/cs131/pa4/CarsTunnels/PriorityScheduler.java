package cs131.pa4.CarsTunnels;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

import cs131.pa4.Abstract.Scheduler;
import cs131.pa4.Abstract.Tunnel;
import cs131.pa4.Abstract.Vehicle;



/**
 * The priority scheduler assigns vehicles to tunnels based on their priority
 * It extends the Scheduler class.
 *
 * @author cs131a
 *
 */
//add comments
public class PriorityScheduler extends Scheduler{

	private final ReentrantLock lock = new ReentrantLock(); //lock for thread saftey
	private final Condition canEnter = lock.newCondition(); //condition variable for signaling when vehicles can enter
	private final Map<Vehicle, Tunnel> vehicleTunnelMap = new HashMap<>(); //map to track which vehicle is in which tunnel
	private int highestPriority = -1; //tracks the highest priority among all the waiting vehicles
	private int waitingVehicles = 0; //tracks the number of vehicles waiting to enter the tunnels

	/**
	 * Creates an instance of a priority scheduler with the given name and tunnels
	 * @param name the name of the priority scheduler
	 * @param tunnels the tunnels where the vehicles will be scheduled to
	 */
	public PriorityScheduler(String name, Collection<Tunnel> tunnels) {
		super(name, tunnels);
	}

	/**
	 * This function admits or enters a vehicle into a tunnel based on its priority.
	 * Vehicles with higher priority (higher integer values) are admitted first.
	 * @param vehicle the vehicle to be admitted into a tunnel
	 * @return the tunnel that the vehicle has been admitted into
	 */
	@Override
	public Tunnel admit(Vehicle vehicle) {
		lock.lock(); //thread safety lock
		try{
			//update waiting vehicles count and highest priority
			waitingVehicles++;
			if(vehicle.getPriority() > highestPriority){
				highestPriority = vehicle.getPriority();
			}

			//wait until the current vehicle has the highest priority
			while(vehicle.getPriority() < highestPriority){
				try{
					canEnter.await();
				}
				catch(InterruptedException e){
					Thread.currentThread().interrupt(); //restore interrupted status
					waitingVehicles--; //decrease waiting vehicles count
					if(waitingVehicles == 0){ //reset highest priority if no vehicles are waiting
						highestPriority = -1;
					}
					return null;
				}
			}

			//try to enter a tunnel
			Tunnel enteredTunnel = null;
			while(enteredTunnel == null){
				//check if a higher priority vehicle has arrived; if so, wait
				if(vehicle.getPriority() < highestPriority){
					try{
						canEnter.await();
						continue;
					}
					catch (InterruptedException e){
						Thread.currentThread().interrupt();
						waitingVehicles--;
						if(waitingVehicles == 0){
							highestPriority = -1;
						}
						return null;
					}
				}

				//attempting to enter each tunnel
				for(Tunnel tun : getTunnels()){
					if(tun.tryToEnter(vehicle)){
						enteredTunnel = tun;
						break;
					}
				}
				
				//wait if no tunnel was entered
				if(enteredTunnel == null){
					try{
						canEnter.await();
					}
					catch (InterruptedException e){
						Thread.currentThread().interrupt();
						waitingVehicles--;
						if(waitingVehicles == 0){
							highestPriority = -1;
						}
						return null;
					}
				}
			}

			waitingVehicles--;
			vehicleTunnelMap.put(vehicle, enteredTunnel);//map the vehicle to the tunnel it entered
			if(waitingVehicles == 0){
				highestPriority = -1;
			}
			else{
				highestPriority = -1; //reset after each entry
			}

			canEnter.signalAll(); //signal all waiting vehicles when one successfully enters
			return enteredTunnel;
		}
		finally{
			lock.unlock(); //release lock
		}
		

	}
	
	/**
	 * This function allows a vehicle to exit the tunnel it is currently in.
	 * @param vehicle the vehicle that is exiting the tunnel
	 */
	@Override
	public void exit(Vehicle vehicle) {
		lock.lock(); //thread safety lock
		try{
			Tunnel tun = vehicleTunnelMap.remove(vehicle); //get the tunnel the vehicle is in and remove it from the map
			if(tun != null){
				tun.exitTunnel(vehicle); //exit the tunnel
				canEnter.signalAll(); //signal all waiting vehicles that a vehicle has exited
			}
		}
		finally{
			lock.unlock(); //release lock
		}
		
	}
	
}

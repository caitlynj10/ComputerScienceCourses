package cs131.pa4.CarsTunnels;

import cs131.pa4.Abstract.Direction;
import cs131.pa4.Abstract.Tunnel;
import cs131.pa4.Abstract.Vehicle;

/**
 * The class for the Basic Tunnel, extending Tunnel.
 *
 * @author cs131a
 *
 */
/**
 * BasicTunnel class from PA3
 */
public class BasicTunnel extends Tunnel {

    /**
     * Variables from BasicTunnel in PA3
     */
    private int occupancy = 0;
	private Direction currentDirection = null; 
	private final int MAX_VEHICLE_OCCUPANCY = 3; 
	private boolean sledThere = false; 
	

    /**
     * Creates a new instance of a basic tunnel with the given name
     *
     * @param name the name of the basic tunnel
     */
    public BasicTunnel(String name) {
        super(name);
    }

    /**
	 * This function attempts to allow a vehicle to enter the tunnel.
	 * It checks the current vehicle occupancy, direction, and type 
	 * of vehicle to determine if entry is	allowed. 
	 * @param vehicle the vehicle attempting to enter the tunnel
	 * @return true if the vehicle is allowed to enter, false otherwise
	 */
    @Override
    protected boolean tryToEnterInner(Vehicle vehicle) {
        boolean isSled = (vehicle instanceof Sled); 
	    synchronized (this){ 
			if(occupancy == 0){
				currentDirection = vehicle.getDirection();
				occupancy++;
				sledThere = isSled;  
				return true;
			}

			if(isSled){ 
				return false;
			}

			if(sledThere){ 
				return false;
			}

			if(vehicle.getDirection() != currentDirection){ 
				return false;
			}

			if(occupancy < MAX_VEHICLE_OCCUPANCY){ 
				occupancy++;
				return true;
			}	
			return false;

		}
    }

    /**
	 * This function updates the tunnel's state when a vehicle exits.
	 * It updates the occupancy, sled presence, and direction.
	 */
    @Override
    protected void exitTunnelInner(Vehicle vehicle) {
        synchronized(this){
			if(occupancy > 0){
				occupancy--;
				if(vehicle instanceof Sled){
					sledThere = false;
				}
				if(occupancy == 0){
					currentDirection = null;
				}
			}
		}

    }

}
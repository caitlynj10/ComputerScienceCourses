# smart-pantry
A Web App that keeps track of food in your kitchen, when it expires, and suggests how to use it to reduce food waste!

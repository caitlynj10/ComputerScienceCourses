import React, { useState, useEffect } from 'react';
import { Mic, Square, SkipForward, Check, X, ArrowBigRight } from 'lucide-react';
import './MicrophoneInput.css'; 

export default function MicrophoneInput({ onAdd, onClose }) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    quantity: '',
    expiry: '',
  });
  const [recognition, setRecognition] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState('');

  const steps = [
    {
      question: "What item would you like to add to your pantry?",
      field: 'name',
      placeholder: 'e.g., Bananas, Milk, Chicken',
    },
    {
      question: "What is the quantity of the item?",
      field: 'quantity',
      placeholder: 'e.g., 6 pieces, 500g, 1L',
    },
    {
      question: "When does it expire? You can say things like '3 days', '1 week', or 'December 31st'",
      field: 'expiry',
      placeholder: 'e.g., 3 days, 1 week, 2024-12-31',
    },
  ];

  // Initialize speech recognition
  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    
    if (!SpeechRecognition) {
      setError('Speech recognition is not supported in your browser. Please use Chrome, Edge, or Safari.');
      return;
    }

    const recognitionInstance = new SpeechRecognition();
    recognitionInstance.continuous = false;
    recognitionInstance.interimResults = false;
    recognitionInstance.lang = 'en-US';

    recognitionInstance.onstart = () => {
      setIsListening(true);
      setError('');
    };

    recognitionInstance.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      setTranscript(transcript);
      
      // Process the transcript based on current step
      processTranscript(transcript);
    };

    recognitionInstance.onerror = (event) => {
      console.error('Speech recognition error:', event.error);
      setError(`Error: ${event.error}. Please try again.`);
      setIsListening(false);
    };

    recognitionInstance.onend = () => {
      setIsListening(false);
    };

    setRecognition(recognitionInstance);

    return () => {
      if (recognitionInstance) {
        recognitionInstance.stop();
      }
    };
  }, []);

  // Speak the current question
  useEffect(() => {
    if ('speechSynthesis' in window) {
      // Stop any ongoing speech
      window.speechSynthesis.cancel();
      
      // Create and speak the question
      const utterance = new SpeechSynthesisUtterance(steps[currentStep].question);
      utterance.rate = 1.0;
      utterance.pitch = 1.0;
      
      // Wait a moment before speaking
      const timer = setTimeout(() => {
        window.speechSynthesis.speak(utterance);
      }, 300);
      
      return () => {
        clearTimeout(timer);
        window.speechSynthesis.cancel();
      };
    }
  }, [currentStep]);

  const processTranscript = (text) => {
    setIsProcessing(true);
    
    const currentField = steps[currentStep].field;
    
    // Basic processing - you might want to enhance this
    let processedText = text.trim();
    
    // Remove common phrases
    processedText = processedText
      .replace(/^(i (have|want|need|would like) )/i, '')
      .replace(/^(it is|it's|the )/i, '')
      .replace(/\s*\.\s*$/, '')
      .trim();
    
    // Process based on field
    switch (currentField) {
      case 'quantity':
        // Handle common quantity expressions
        processedText = processedText
          .replace(/^a /i, '1 ')
          .replace(/^an /i, '1 ')
          .replace(/^one /i, '1 ')
          .replace(/^two /i, '2 ')
          .replace(/^three /i, '3 ')
          .replace(/^four /i, '4 ')
          .replace(/^five /i, '5 ')
          .replace(/^six /i, '6 ')
          .replace(/^seven /i, '7 ')
          .replace(/^eight /i, '8 ')
          .replace(/^nine /i, '9 ')
          .replace(/^ten /i, '10 ');
        break;
        
      case 'expiry':
        // Process relative dates
        processedText = processedText.toLowerCase();
        if (processedText.includes('tomorrow')) {
          processedText = '1 day';
        } else if (processedText.includes('next week')) {
          processedText = '1 week';
        } else if (processedText.includes('next month')) {
          processedText = '1 month';
        } else if (processedText.includes('in ') && processedText.includes(' days')) {
          // Extract number of days
          const match = processedText.match(/in (\d+) days?/i);
          if (match) {
            processedText = `${match[1]} days`;
          }
        }
        break;
    }
    
    // Update form data
    setFormData(prev => ({
      ...prev,
      [currentField]: processedText
    }));
    
    // Speak confirmation
    if ('speechSynthesis' in window) {
      const confirmation = new SpeechSynthesisUtterance(`Got it. ${processedText}`);
      confirmation.rate = 1.0;
      
      confirmation.onend = () => {
        setIsProcessing(false);
        
        // Auto-advance after a delay if not last step
        if (currentStep < steps.length - 1) {
          setTimeout(() => {
            setCurrentStep(prev => prev + 1);
            setTranscript('');
          }, 1000);
        }
      };
      
      window.speechSynthesis.speak(confirmation);
    } else {
      setIsProcessing(false);
      if (currentStep < steps.length - 1) {
        setTimeout(() => {
          setCurrentStep(prev => prev + 1);
          setTranscript('');
        }, 1000);
      }
    }
  };

  const startListening = () => {
    if (recognition && !isListening) {
      try {
        recognition.start();
      } catch (err) {
        console.error('Failed to start recognition:', err);
        setError('Failed to start microphone. Please check permissions.');
      }
    }
  };

  const stopListening = () => {
    if (recognition && isListening) {
      recognition.stop();
    }
  };

  const handleSkip = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(prev => prev + 1);
      setTranscript('');
    }
  };

  const handleSubmit = () => {
    // Ensure we have at least a name
    if (!formData.name.trim()) {
      setError('Please provide an item name');
      return;
    }
    
    // Submit the item
    onAdd({
      name: formData.name,
      quantity: formData.quantity || '1',
      expiry: formData.expiry || 'Unknown',
    });
    
    // Close the modal
    onClose();
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
      setTranscript('');
    }
  };

  return (
    <div className="microphone-input-modal">
      <div className="voice-content">
        {/* Current step indicator */}
        <div className="step-indicator">
          {steps.map((_, index) => (
            <div
              key={index}
              className={`step-dot ${index === currentStep ? 'active' : ''} ${index < currentStep ? 'completed' : ''}`}
            />
          ))}
        </div>
        
        {/* Current question */}
        <div className="question-container">
          <p className="question-text">{steps[currentStep].question}</p>
          <p className="question-hint">{steps[currentStep].placeholder}</p>
        </div>
        
        {/* Current field value */}
        {formData[steps[currentStep].field] && (
          <div className="current-value">
            <span className="value-label">You said:</span>
            <span className="value-text">{formData[steps[currentStep].field]}</span>
          </div>
        )}
        
        {/* Transcript display */}
        {transcript && (
          <div className="transcript">
            <span className="transcript-label">Listening:</span>
            <span className="transcript-text">{transcript}</span>
          </div>
        )}
        
        {/* Microphone visualization */}
        <div className="microphone-container">
          <button
            className={`microphone-btn ${isListening ? 'listening' : ''} ${isProcessing ? 'processing' : ''}`}
            onClick={isListening ? stopListening : startListening}
            disabled={isProcessing}
          >
            {isListening ? (
              <Square size={48} className="stop-icon" />
            ) : (
              <Mic size={48} className="mic-icon" />
            )}
            
            {/* Animated waves when listening */}
            {isListening && (
              <div className="sound-waves">
                <div className="wave"></div>
                <div className="wave"></div>
                <div className="wave"></div>
              </div>
            )}
          </button>
          
          <p className="microphone-instruction">
            {isListening 
              ? "Listening... Speak now" 
              : isProcessing 
                ? "Processing..." : ""}
          </p>
        </div>
        
        {/* Error message */}
        {error && (
          <div className="error-message">
            <p>{error}</p>
          </div>
        )}
        
        {/* Form data preview */}
        {currentStep > 0 && (
          <div className="form-preview">
            <div className="preview-items">
              {formData.name && (
                <div className="preview-item">
                  <span className="preview-label">Item:  </span>
                  <span className="preview-value">{formData.name}</span>
                </div>
              )}
              {formData.quantity && (
                <div className="preview-item">
                  <span className="preview-label">Quantity:  </span>
                  <span className="preview-value">{formData.quantity}</span>
                </div>
              )}
              {formData.expiry && (
                <div className="preview-item">
                  <span className="preview-label">Expiry:  </span>
                  <span className="preview-value">{formData.expiry}</span>
                </div>
              )} 
            </div>
          </div>
        )}
        
        {/* Action buttons */}
        <div className="voice-actions">
          {currentStep > 0 && (
            <button 
              className="btn btn-secondary" 
              onClick={handleBack}
              disabled={isListening || isProcessing}
            >
              Back
            </button>
          )}
          
          {currentStep < steps.length - 1 ? (
            <button 
              className="btn btn-secondary" 
              onClick={handleSkip}
              disabled={isListening || isProcessing}
            >
              <ArrowBigRight size={16} />
              Next
            </button>
          ) : (
            <button 
              className="btn btn-primary" 
              onClick={handleSubmit}
              disabled={!formData.name.trim() || isListening || isProcessing}
            >
              <Check size={16} />
              Add to Pantry
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
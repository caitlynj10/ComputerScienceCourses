"use client";
import React, { useRef, useState, useEffect } from "react";
import Tesseract from "tesseract.js";
import Pantry from "../pages/Pantry";


export default function ReceiptScanner({ onExtract, onClose }) {
  const fileInputRef = useRef(null);
  const [loading, setLoading] = useState(false);
  const [foodWords, setFoodWords] = useState([]);

  // Load food keywords from public/food.txt
  useEffect(() => {
    fetch("/food.txt")
      .then((res) => res.text())
      .then((txt) => {
        const words = txt
          .split("\n")
          .map((w) => w.trim().toLowerCase())
          .filter(Boolean);
        setFoodWords(words);
      });
  }, []);

  // Capitalizes each word
  const toTitleCase = (str) =>
    str
      .toLowerCase()
      .split(" ")
      .filter(Boolean)
      .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
      .join(" ");

  const extractItemFromLine = (rawLine) => {
    let name = rawLine;

    // Remove ALL numbers and prices
    name = name.replace(/\d+[.,]\d+/g, ""); // Removes decimal numbers like 2.00, 1,50
    name = name.replace(/\$\d+/g, ""); // Removes $2, $15
    name = name.replace(/\d+/g, ""); // Removes all remaining numbers
    
    // Remove units (kg, g, lb, oz, x, pcs)
    name = name.replace(/\b(kg|g|lb|oz|x|pcs)\b/gi, "");

    // Remove extra spaces and clean up
    name = name.replace(/\s+/g, " ").trim();

    // Title Case
    name = toTitleCase(name);

    return {
      name: name || rawLine,
      quantity: "1",
      expiry: "Unknown",
    };
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setLoading(true);

    try {
      const result = await Tesseract.recognize(file, "eng");
      const text = result.data.text;

      const lines = text
        .split("\n")
        .map((l) => l.trim())
        .filter(Boolean);

      // Choose lines containing real food items
      const foodLines = lines.filter((line) => {
        const lower = line.toLowerCase();
        return foodWords.some((word) => lower.includes(word));
      });

      const extracted = foodLines.map(extractItemFromLine);

      onExtract(extracted);
    } catch (err) {
      console.error(err);
      alert("Failed to read receipt text.");
    }

    setLoading(false);
    onClose();
  };

  return (
    <div className="receipt-scanner">
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        style={{ display: "none" }}
        onChange={handleImageUpload}
      />

      <button className="btn btn-secondary" onClick={onClose}>
        Back
      </button>

      <button
        className="btn btn-primary"
        onClick={() => fileInputRef.current.click()}
      >
        {loading ? "Scanning..." : "Take Receipt Photo"}
      </button>
    </div>
  );
}
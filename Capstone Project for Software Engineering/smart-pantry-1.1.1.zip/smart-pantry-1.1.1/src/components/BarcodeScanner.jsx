"use client";
import React, { useEffect } from "react";
import Quagga from "@ericblade/quagga2";

export default function BarcodeScanner({ onDetected, onClose }) {
  useEffect(() => {
    const config = {
      inputStream: {
        type: "LiveStream",
        target: document.querySelector("#camera"),
        constraints: {
          width: { min: 640 },
          height: { min: 480 },
          facingMode: "environment",
        },
      },
      decoder: {
        readers: ["ean_reader", "upc_reader", "code_128_reader"],
      },
      locate: true,
    };

    Quagga.init(config, (err) => {
      if (err) {
        console.error("Quagga init error:", err);
        return;
      }
      Quagga.start();
    });

    Quagga.onDetected((data) => {
      const code = data?.codeResult?.code;
      if (code) {
        Quagga.stop();
        onDetected(code);
      }
    });

    return () => {
      Quagga.stop();
      Quagga.offDetected();
    };
  }, [onDetected]);

  return null;
}
/**
 * User specific data storage
 * @returns 
 */
export function getCurrentUser() {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem('sp_user');
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error("Error getting current user", e);
  }
  return null;
}

export function getUserId() {
  const user = getCurrentUser();
  return user?.username || null;
}

export function saveUserData(username, data) {
  if (typeof window === "undefined") return;
  try {
    const key = `sp_user_data_${username}`;
    localStorage.setItem(key, JSON.stringify(data));
  } catch (e) {
    console.error("Error saving user data", e);
  }
}

export function getUserData(username) {
  if (typeof window === "undefined") return null;
  try {
    const key = `sp_user_data_${username}`;
    const raw = localStorage.getItem(key);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error("Error getting user data", e);
  }
  return null;
}

export function updateUserProfile(updates) {
  const user = getCurrentUser();
  if (!user) return;
  
  try {
    const updatedUser = { ...user, ...updates };
    localStorage.setItem('sp_user', JSON.stringify(updatedUser));
    
    const userData = getUserData(user.username) || {};
    userData.profile = updatedUser;
    saveUserData(user.username, userData);
    window.dispatchEvent(new Event('profilePictureUpdated'));
    return updatedUser;
  } catch (e) {
    console.error("Error updating user profile", e);
    return null;
  }
}


export function savePantryItems(items) {
  const user = getCurrentUser();
  if (!user) return;
  
  const userData = getUserData(user.username) || {};
  userData.pantryItems = items;
  saveUserData(user.username, userData);
}

export function getPantryItems() {
  const user = getCurrentUser();
  if (!user) return [];
  
  const userData = getUserData(user.username);
  return userData?.pantryItems || [];
}

export function saveShoppingListItems(items) {
  const user = getCurrentUser();
  if (!user) return;
  
  const userData = getUserData(user.username) || {};
  userData.shoppingListItems = items;
  saveUserData(user.username, userData);
}

export function getShoppingListItems() {
  const user = getCurrentUser();
  if (!user) return [];
  
  const userData = getUserData(user.username);
  return userData?.shoppingListItems || [];
}


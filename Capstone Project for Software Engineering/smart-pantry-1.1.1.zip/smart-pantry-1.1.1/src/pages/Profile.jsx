import { useState, useEffect, useRef } from 'react';
import './Profile.css';
import { Camera, X, Check } from 'lucide-react';
import { getCurrentUser, updateUserProfile } from '../utils/userStorage.js';

function getUserFromLocalStorage(){
  return getCurrentUser();
}

export default function Profile() {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [profilePicture, setProfilePicture] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);

  useEffect(() => {
    const userFromStorage = getUserFromLocalStorage();
    setUser(userFromStorage);
    setProfilePicture(userFromStorage?.profilePicture || '/images/profile-picture.png');
    setIsLoading(false);
  }, []);

  const updateUser = (updatedUser) => {
    setUser(updatedUser);
    setProfilePicture(updatedUser.profilePicture || '/images/profile-picture.png');
  };

  if (isLoading){
    return(
      <main className="home-body">
        <div className="profile-header">
          <h1 className="user-name">Loading...</h1>
        </div>
      </main>
    )
  }

  return (
    <main className="home-body">
      <Header user={user} profilePicture={profilePicture} />
      <SubHeader user={user} setShowEditModal={setShowEditModal} />
      <ProfBody user={user}/>
      {showEditModal && (
        <EditProfileModal 
          user={user} 
          updateUser={updateUser}
          closeModal={() => setShowEditModal(false)}
        />
      )}
    </main>
  );
}

function Header({user, profilePicture}){
  const capitalizedName = user.name.charAt(0).toUpperCase() + user.name.slice(1);
 
  return(
    <div className = "profile-header">
      <h1 className= "user-name">{capitalizedName}</h1>
      <img className = "profile-pic" src = {profilePicture} alt="Profile"/>
      <h2 className = "username"> @{user.username}</h2>
    </div>
  );
}

function SubHeader({user, setShowEditModal}) {
  const handleSignOut = () => {
    try { localStorage.removeItem('sp_user') } catch (e) {}
    window.location.reload()
  }

  if (!user){
    return null;
  }

  return (
    <div className="sub-header">
      <button className="edit-button" onClick={() => setShowEditModal(true)}>
        Edit Profile
      </button>
      <button className="sign-out-button" onClick={handleSignOut}>
       Sign out
      </button>
    </div>
  );
}

function EditProfileModal({ user, updateUser, closeModal }) {
  const fileInputRef = useRef(null);
  const [previewImage, setPreviewImage] = useState(user.profilePicture || '/images/profile-picture.png');
  const [hasNewImage, setHasNewImage] = useState(false);

  const handleFileSelect = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        alert('Please select an image file');
        return;
      }
      
      if (file.size > 5 * 1024 * 1024) {
        alert('Image size should be less than 5MB');
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result);
        setHasNewImage(true);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    try {
      const updatedUser = updateUserProfile({ profilePicture: previewImage });
      if (updatedUser) {
        updateUser(updatedUser);
        closeModal();
      } else {
        alert('Failed to save profile picture');
      }
    } catch (e) {
      console.error('Error saving profile picture:', e);
      alert('Failed to save profile picture');
    }
  };

  return (
    <div className="modal-overlay" onClick={closeModal}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>Edit Profile Picture</h2>
          <button className="modal-close" onClick={closeModal}>
            <X size={24} />
          </button>
        </div>

        <div className="modal-body">
          <div className="preview-section">
            <div className="preview-circle">
              <img 
                src={previewImage} 
                alt="Preview"
              />
            </div>
          </div>

          <button 
            className="upload-button" 
            onClick={() => fileInputRef.current?.click()}
          >
            <Camera size={20} />
            <span>{hasNewImage ? 'Choose Different Photo' : 'Upload Photo'}</span>
          </button>
          <input 
            ref={fileInputRef}
            type="file" 
            accept="image/*" 
            onChange={handleFileSelect}
            style={{ display: 'none' }}
          />
        </div>

        <div className="modal-footer">
          <button className="cancel-button" onClick={closeModal}>
            Cancel
          </button>
          <button className="save-button" onClick={handleSave}>
            <Check size={20} />
            <span>Save Changes</span>
          </button>
        </div>
      </div>
    </div>
  );
}

function ProfBody({user}) {
  const stats = [
    { label: "Recipes Cooked", value: "47" },
    { label: "Cook Time", value: "128h" },
    { label: "Ingredients Saved", value: "156" }
  ];

  return (
    <div className="user-stats">
      {stats.map((stat, index) => (
        <div key={index} className="stats-card">
          <div className="stats-value">{stat.value}</div>
          <div className="stats-label">{stat.label}</div>
        </div>
      ))}
    </div>
  );
}



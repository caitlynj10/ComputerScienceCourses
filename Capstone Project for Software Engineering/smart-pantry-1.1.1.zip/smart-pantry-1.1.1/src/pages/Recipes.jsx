import { useEffect, useMemo, useState } from "react";
import "./Recipes.css";
import { Search } from "lucide-react";
import supabase from "../supabase-client";
import { getUserId } from "../utils/userStorage";

const API = import.meta.env.VITE_SPOONACULAR_URL;
const KEY = import.meta.env.VITE_SPOONACULAR_KEY;

const normalize = (s = "") => s.toLowerCase().trim();

/* =======================
   Expiry helpers
   ======================= */

function parseExpiryToDays(expiry) {
  if (!expiry) return Infinity;

  if (/^\d{4}-\d{2}-\d{2}/.test(expiry)) {
    const diff = new Date(expiry) - new Date();
    return Math.max(0, Math.round(diff / 86400000));
  }

  const m = expiry.toLowerCase().match(/(\d+)\s*(day|week|month|year)/);
  if (!m) return Infinity;

  const mult = { day: 1, week: 7, month: 30, year: 365 }[m[2]];
  return parseInt(m[1], 10) * mult;
}

function formatExpiryText(name, days, expiryRaw) {
  const item = name.charAt(0).toUpperCase() + name.slice(1);

  if (days === 0) return `${item} expires today`;
  if (days === 1) return `${item} expires tomorrow`;
  if (days <= 7) return `${item} expires in ${days} days`;

  if (expiryRaw && /^\d{4}-\d{2}-\d{2}/.test(expiryRaw)) {
    return `${item} expires on ${new Date(expiryRaw).toLocaleDateString()}`;
  }

  return null;
}

function scoreByExpiry(recipe, pantry) {
  const used = recipe.usedIngredients || [];
  let score = 0;

  used.forEach(ui => {
    const match = pantry.find(
      p =>
        normalize(p.name).includes(normalize(ui.name)) ||
        normalize(ui.name).includes(normalize(p.name))
    );

    if (match) {
      const days = parseExpiryToDays(match.expiry);
      score += 1 / (1 + days);
    }
  });

  return score;
}

function getSoonestItem(recipe, pantry) {
  const used = recipe.usedIngredients || [];
  let best = null;
  let bestDays = Infinity;

  used.forEach(ui => {
    const match = pantry.find(
      p =>
        normalize(p.name).includes(normalize(ui.name)) ||
        normalize(ui.name).includes(normalize(p.name))
    );

    if (match) {
      const d = parseExpiryToDays(match.expiry);
      if (d < bestDays) {
        bestDays = d;
        best = match;
      }
    }
  });

  return { item: best, days: bestDays };
}

/* =======================
   Instructions helper
   ======================= */

function instructionsToSteps(html) {
  if (!html) return [];
  const div = document.createElement("div");
  div.innerHTML = html;

  const lis = Array.from(div.querySelectorAll("li")).map(li =>
    li.textContent.trim()
  );

  return lis.length ? lis : [div.textContent.trim()];
}

/* =======================
   Recipes Page
   ======================= */

export default function Recipes() {
  const [pantry, setPantry] = useState([]);
  const [recipes, setRecipes] = useState([]);
  const [details, setDetails] = useState({});
  const [query, setQuery] = useState("");
  const [selectedId, setSelectedId] = useState(null);

  const userId = getUserId();

  /* Load pantry */
  useEffect(() => {
    if (!userId) return;

    supabase
      .from("Pantry")
      .select("name, expir_date")
      .eq("user_id", userId)
      .then(({ data }) => {
        if (data) {
          setPantry(
            data.map(p => ({
              name: p.name,
              expiry: p.expir_date,
            }))
          );
        }
      });
  }, [userId]);

  /* Fetch recipes */
  useEffect(() => {
    if (!pantry.length) return;

    const fetchAll = async () => {
      const map = new Map();

      for (const p of pantry.slice(0, 6)) {
        const ingredient = p.name
          .toLowerCase()
          .replace(/[^a-z\s]/g, "")
          .trim();

        if (!ingredient) continue;

        const res = await fetch(
          `${API}/recipes/findByIngredients?` +
            `ingredients=${encodeURIComponent(ingredient)}` +
            `&number=5&ranking=2&ignorePantry=false&apiKey=${KEY}`
        );

        const json = await res.json();

        (json || []).forEach(r => {
          if (!map.has(r.id)) {
            map.set(r.id, r);
          } else {
            const ex = map.get(r.id);
            const names = new Set(
              (ex.usedIngredients || []).map(i => normalize(i.name))
            );
            (r.usedIngredients || []).forEach(i => {
              if (!names.has(normalize(i.name))) {
                ex.usedIngredients.push(i);
              }
            });
          }
        });
      }

      setRecipes([...map.values()]);
    };

    fetchAll();
  }, [pantry]);

  /* Search + smart expiry ranking */
  const visible = useMemo(() => {
    const filtered = recipes.filter(r =>
      !query || normalize(r.title).includes(normalize(query))
    );

    return filtered
      .slice()
      .sort((a, b) => scoreByExpiry(b, pantry) - scoreByExpiry(a, pantry));
  }, [recipes, pantry, query]);

  /* Modal details */
  const openModal = async id => {
    setSelectedId(id);
    if (details[id]) return;

    const res = await fetch(`${API}/recipes/${id}/information?apiKey=${KEY}`);
    const json = await res.json();

    setDetails(prev => ({
      ...prev,
      [id]: {
        time: json.readyInMinutes,
        instructions: json.instructions,
        sourceUrl: json.sourceUrl,          // ORIGINAL LINK
      },
    }));
  };

  const closeModal = () => setSelectedId(null);

  const selectedRecipe = visible.find(r => r.id === selectedId);

  /* Render */
  return (
    <main className="recipes">
      <section className="recipes__controls">
        <div className="recipes__search-wrapper">
          <Search size={18} />
          <input
            className="recipes__search"
            placeholder="Search recipes..."
            value={query}
            onChange={e => setQuery(e.target.value)}
          />
        </div>
      </section>

      <section className="recipes__grid">
        {visible.map(r => {
          const { item: soonestItem, days: soonestDays } = getSoonestItem(
            r,
            pantry
          );

          const badgeText = soonestItem
            ? formatExpiryText(
                soonestItem.name,
                soonestDays,
                soonestItem.expiry
              )
            : null;

          const usedNames = (r.usedIngredients || []).map(i => i.name);
          let usedText = "Uses items from your pantry";
          if (usedNames.length === 1) {
            usedText = `Uses ${usedNames[0]} from your pantry`;
          } else if (usedNames.length > 1) {
            usedText = `Uses ${usedNames.slice(0, -1).join(", ")} and ${
              usedNames.at(-1)
            } from your pantry`;
          }

          return (
            <div
              className="recipe-card"
              key={r.id}
              onClick={() => openModal(r.id)}
            >
              <div className="recipe-card__image-wrapper">
                <img
                  src={r.image}
                  alt={r.title}
                  className="recipe-card__image"
                />
                {badgeText && (
                  <span className="recipe-card__badge">{badgeText}</span>
                )}
              </div>

              <div className="recipe-card__content">
                <h3>{r.title}</h3>
                <p className="recipe-card__meta">{usedText}</p>
                <button
                  className="recipe-card__btn"
                  onClick={e => {
                    e.stopPropagation();
                    openModal(r.id);
                  }}
                >
                  View Recipe
                </button>
              </div>
            </div>
          );
        })}
      </section>

      {selectedRecipe && (
        <div className="recipe-modal__backdrop" onClick={closeModal}>
          <div
            className="recipe-modal"
            onClick={e => e.stopPropagation()}
          >
            <button className="recipe-modal__close" onClick={closeModal}>
              ×
            </button>

            <h2>{selectedRecipe.title}</h2>
            <img
              src={selectedRecipe.image}
              alt={selectedRecipe.title}
              className="recipe-modal__image"
            />

            {details[selectedRecipe.id] ? (
              <>
                {details[selectedRecipe.id].time != null && (
                  <p>
                    <strong>Time:</strong>{" "}
                    {details[selectedRecipe.id].time} min
                  </p>
                )}

                <h3>Instructions</h3>
                <ol>
                  {instructionsToSteps(
                    details[selectedRecipe.id].instructions
                  ).map((s, i) => (
                    <li key={i}>{s}</li>
                  ))}
                </ol>

                {/* ⭐ ORIGINAL RECIPE LINK */}
                {details[selectedRecipe.id].sourceUrl && (
                  <a
                    href={details[selectedRecipe.id].sourceUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="recipe-modal__source"
                  >
                    View original recipe ↗
                  </a>
                )}
              </>
            ) : (
              <p>Loading recipe...</p>
            )}
          </div>
        </div>
      )}
    </main>
  );
}

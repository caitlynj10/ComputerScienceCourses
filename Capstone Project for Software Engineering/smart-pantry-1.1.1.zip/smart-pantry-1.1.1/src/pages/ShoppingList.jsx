
"use client";
import React, { useState, useEffect } from "react";
import { Keyboard, Mic, X, Plus, Edit2, Trash2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import "./Pantry.css";
import supabase from '../supabase-client.js';
import { getUserId} from '../utils/userStorage.js';

export default function ShoppingList() {
  const [open, setOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [shoppingItems, setShoppingItems] = useState([]);
  const userId = getUserId();
  const navigate = useNavigate();

  // Fetch items from Supabase on mount
  useEffect(() => {
    if (!userId) return;
    let mounted = true;
    (async () => {
      try {
        const { data, error } = await supabase
          .from('ShoppingList')
          .select('id, name, amount_value, amount_unit')
          .eq('user_id', userId)
          .order('id', { ascending: true });

        if (!error && mounted) {
          const mapped = (data || []).map((r) => ({
            id: r.id,
            name: r.name,
            quantity: r.amount_value != null ? `${r.amount_value} ${r.amount_unit || ''}`.trim() : (r.amount_unit || ''),
            _raw: r,
          }));
          setShoppingItems(mapped);
        }
      } catch (err) {
        if (mounted) console.error('Fetch shopping list failed', err);
      }
    })();

    return () => { mounted = false; };
  }, [userId]);

  const handleAddItem = async (item) => {
    if (!userId){
      alert('User not signed in. Please sign in to add items to your shopping list.');
      return;
    }
    // item has { name, quantity } from modal
    const { amount_value, amount_unit } = parseQuantity(item.quantity || '');
    const payload = { name: item.name, amount_value, amount_unit, user_id: userId };
    try {
      const { data, error } = await supabase.from('ShoppingList').insert([payload]).select();
      if (error) {
        console.error('Error inserting item:', error);
      } else {
        const r = data[0];
        const mapped = {
          id: r.id,
          name: r.name,
          quantity: r.amount_value != null ? `${r.amount_value} ${r.amount_unit || ''}`.trim() : (r.amount_unit || ''),
          _raw: r,
        };
        setShoppingItems((prev) => [mapped, ...prev]);
      }
    } catch (err) {
      console.error('Insert failed', err);
    }

    setOpen(false);
  };

  const handleDelete = async (idx) => {
    const current = shoppingItems[idx];
    if (!current) return;

    try {
      const { error } = await supabase.from('ShoppingList').delete().eq('id', current.id);
      if (error) {
        console.error('Error deleting item:', error);
      } else {
        setShoppingItems((prev) => prev.filter((_, i) => i !== idx));
      }
    } catch (err) {
      console.error('Delete failed', err);
    }

    setSelectedItem(null);
  };

  const handleUpdate = async (idx, updated) => {
    const current = shoppingItems[idx];
    if (!current) return;

    const { amount_value, amount_unit } = parseQuantity(updated.quantity || '');
    const payload = { name: updated.name, amount_value, amount_unit };

    try {
      const { data, error } = await supabase.from('ShoppingList').update(payload).eq('id', current.id).select();
      if (error) {
        console.error('Error updating item:', error);
      } else {
        const r = data[0];
        const mapped = {
          id: r.id,
          name: r.name,
          quantity: r.amount_value != null ? `${r.amount_value} ${r.amount_unit || ''}`.trim() : (r.amount_unit || ''),
          _raw: r,
        };
        setShoppingItems((prev) => prev.map((it, i) => (i === idx ? mapped : it)));
      }
    } catch (err) {
      console.error('Update failed', err);
    }

    setSelectedItem(null);
  };

  // move an item from ShoppingList table to Pantry table
  const moveToPantry = async (idx) => {
    const current = shoppingItems[idx];
    if (!current) return;

    // Store the item data in sessionStorage to be picked up by Pantry page
    const raw = current._raw || {};
    let amount_value = raw.amount_value;
    let amount_unit = raw.amount_unit;
    // if not present, try parsing the displayed quantity
    if (amount_value == null && (!amount_unit || amount_unit === '')) {
      const parsed = parseQuantity(current.quantity || '');
      amount_value = parsed.amount_value;
      amount_unit = parsed.amount_unit;
    }

    const itemData = {
      name: current.name,
      amount_value: amount_value == null ? null : amount_value,
      amount_unit: amount_unit || null,
      shoppingListId: current.id,
    };

    sessionStorage.setItem('itemToAdd', JSON.stringify(itemData));
    
    // Navigate to pantry page
    navigate('/pantry');
  };

  function parseQuantity(quantity) {
    // try to parse "2 kg" -> { amount_value: 2, amount_unit: 'kg' }
    if (!quantity) return { amount_value: null, amount_unit: null };
    const m = String(quantity).trim().match(/^\s*(\d+(?:\.\d+)?)\s*(.*)$/);
    if (m) {
      const val = Number(m[1]);
      const unit = (m[2] || '').trim() || null;
      return { amount_value: isNaN(val) ? null : val, amount_unit: unit };
    }
    // fallback: store whole string in unit for freeform quantities
    return { amount_value: null, amount_unit: String(quantity).trim() };
  }

  return (
    <div className="pantry-container">
      <div className="header">
        <div className="header-content">
          <p><span className="bold-text">{shoppingItems.length}</span> items in shopping list</p>
          <button className="btn small-btn" onClick={() => setOpen(true)}>
            <Plus className="icon" />
            Add Item
          </button>
        </div>
      </div>

      <div className="items">
        {shoppingItems.map((item, idx) => (
          <div
            key={item.id}
            className="card"
            style={{ cursor: "pointer" }}
          >
            <div className="card-left" onClick={() => setSelectedItem({ ...item, idx })}>
              <h4>{item.name}</h4>
              <p>{item.quantity}</p>
            </div>
            <div className="card-actions" style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <button
                className="btn"
                onClick={async (e) => {
                  e.stopPropagation();
                  await moveToPantry(idx);
                }}
              >
                Move to Pantry
              </button>
            </div>
          </div>
        ))}
      </div>

      {open && <AddItemModal onClose={() => setOpen(false)} onAdd={handleAddItem} />}
      {selectedItem && (
        <ItemDetailModal
          item={selectedItem}
          onClose={() => setSelectedItem(null)}
          onDelete={() => handleDelete(selectedItem.idx)}
          onUpdate={(updated) => handleUpdate(selectedItem.idx, updated)}
        />
      )}
    </div>
  );
}

function AddItemModal({ onClose, onAdd }) {
  const inputMethods = [
    {
      id: "manual",
      icon: Keyboard,
      label: "Manual Input",
      description: "Type item details",
      color: "#CFE0FF",
    },
    {
      id: "voice",
      icon: Mic,
      label: "Voice Input",
      description: "Say what you need",
      color: "#FFD4D9",
    },
  ];

  const [manualOpen, setManualOpen] = useState(false);
  const [form, setForm] = useState({ name: "", quantity: "" });

  const handleClick = (id) => {
    if (id === "manual") {
      setManualOpen(true);
      return;
    }
    console.log("Selected method:", id);
    onClose();
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.name.trim()) return;
    const newItem = {
      name: form.name.trim(),
      quantity: form.quantity.trim() || "1",
    };
    onAdd(newItem);
    setForm({ name: "", quantity: "" });
    setManualOpen(false);
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>{manualOpen ? "Enter Item Details" : "Add Item to Shopping List"}</h2>
          <button className="close-btn" onClick={onClose}>
            <X />
          </button>
        </div>

        {!manualOpen && (
          <div className="modal-grid">
            {inputMethods.map((m) => {
              const Icon = m.icon;
              return (
                <button key={m.id} className="modal-card" onClick={() => handleClick(m.id)}>
                  <div className="icon-circle" style={{ backgroundColor: m.color }}>
                    <Icon />
                  </div>
                  <span>{m.label}</span>
                  <span className="desc">{m.description}</span>
                </button>
              );
            })}
          </div>
        )}

        {manualOpen && (
          <form className="manual-form" onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="item-name">Item Name</label>
              <input
                id="item-name"
                name="name"
                value={form.name}
                onChange={handleChange}
                placeholder="e.g. Bananas, Milk, Chicken"
                required
                className="form-input"
              />
            </div>

            <div className="form-group">
              <label htmlFor="item-quantity">Quantity</label>
              <input
                id="item-quantity"
                name="quantity"
                value={form.quantity}
                onChange={handleChange}
                placeholder="e.g. 6 pieces, 500g, 1L"
                className="form-input"
              />
              <div className="input-hint">Include units if possible</div>
            </div>

            <div className="modal-actions">
              <button type="button" className="btn btn-secondary" onClick={() => setManualOpen(false)}>
                Cancel
              </button>
              <button type="submit" className="btn btn-primary" disabled={!form.name.trim()}>
                Add Item
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

function ItemDetailModal({ item, onClose, onDelete, onUpdate }) {
  const [editOpen, setEditOpen] = useState(false);
  const [form, setForm] = useState({ name: item.name, quantity: item.quantity });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSave = (e) => {
    e.preventDefault();
    if (!form.name.trim()) return;
    onUpdate({ name: form.name.trim(), quantity: form.quantity.trim() || "1" });
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal small-modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>{editOpen ? "Edit Item" : item.name}</h2>
          <button className="close-btn" onClick={onClose}>
            <X />
          </button>
        </div>

        {!editOpen && (
          <>
            <div className="item-details">
              <div className="detail-row">
                <span className="detail-label">Quantity:</span>
                <span className="detail-value">{item.quantity}</span>
              </div>
            </div>

            <div className="modal-actions modal-actions-stacked">
              <button className="btn btn-edit" onClick={() => setEditOpen(true)}>
                <Edit2 className="icon" /> Edit
              </button>
              <button className="btn btn-delete" onClick={onDelete}>
                <Trash2 className="icon" /> Delete
              </button>
            </div>
          </>
        )}

        {editOpen && (
          <form className="manual-form" onSubmit={handleSave}>
            <div className="form-group">
              <label htmlFor="edit-name">Item Name</label>
              <input
                id="edit-name"
                name="name"
                value={form.name}
                onChange={handleChange}
                required
                className="form-input"
              />
            </div>

            <div className="form-group">
              <label htmlFor="edit-quantity">Quantity</label>
              <input
                id="edit-quantity"
                name="quantity"
                value={form.quantity}
                onChange={handleChange}
                className="form-input"
              />
            </div>

            <div className="modal-actions">
              <button type="button" className="btn btn-secondary" onClick={() => setEditOpen(false)}>
                Cancel
              </button>
              <button type="submit" className="btn btn-primary" disabled={!form.name.trim()}>
                Save Changes
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
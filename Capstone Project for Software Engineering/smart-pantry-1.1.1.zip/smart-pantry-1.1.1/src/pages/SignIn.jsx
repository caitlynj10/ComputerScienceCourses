import { useState } from 'react';
import './SignIn.css';
import {ArrowRight} from 'lucide-react';
import { getUserData } from '../utils/userStorage.js';

export default function SignIn() {
  const [formData, setFormData] = useState({
    name: '',
    username: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    
    if (name === 'username') {
      let cleanValue = value.replace(/^@+/, '');
      cleanValue = cleanValue.replace(/\s/g, '');
      setFormData(prev => ({
        ...prev,
        [name]: cleanValue
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: value
      }));
    }
    setError(''); 
  };

 

  const handleSignIn = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    
    if (!formData.name.trim() || !formData.username.trim()) {
      setError('Please fill in all fields');
      setIsLoading(false);
      return;
    }

    if (formData.username.includes(' ')) {
      setError('Username cannot contain spaces');
      setIsLoading(false);
      return;
    }

    try {
      const username = formData.username.trim();
      const name = formData.name.trim();
      
      // Check if user has existing data
      const existingData = getUserData(username);
      const user = existingData?.profile || {
        name: name,
        username: username
      };
      
      // Make sure name matches if they had different name before
      user.name = name;
      user.username = username;

      localStorage.setItem('sp_user', JSON.stringify(user));
      
      
      setTimeout(() => {
        window.location.href = '/';
      }, 500);

    } catch (e) {
      setError('Failed to save user data. Please try again.');
      setIsLoading(false);
      console.error('Failed to save user:', e);
    }
  };

  return (
    <div className="signin-container">
      <div className="signin-card">
        <div className="signin-header">
            <img src="/images/logo2.png" className="signin-icon"/>
          <h1 className="signin-title">Welcome to Smart Pantry!</h1>
          <p className="signin-subtitle">Sign in to access your personalized pantry</p>
        </div>

        <form className="signin-form" onSubmit={handleSignIn}>
          <div className="form-group">
            <label htmlFor="name" className="form-label" style={{ color: "black"}}>
              First Name
            </label>
            <input
              type="text"
              id="name"
              name="name"
              className="form-input"
              placeholder="Enter your first name"
              value={formData.name}
              onChange={handleInputChange}
              disabled={isLoading}
            />
          </div>

          <div className="form-group">
            <label htmlFor="username" className="form-label" style={{ color: "black" }}>
              Username
            </label>
            <div className="username-input-wrapper">
              <span className="username-prefix">@</span>
              <input
                type="text"
                id="username"
                name="username"
                className="form-input username-input"
                placeholder="username"
                value={formData.username}
                onChange={handleInputChange}
                disabled={isLoading}
              />
            </div>
          </div>

          {error && (
            <div className="error-message">
              {error}
            </div>
          )}

          <button
            type="submit"
            className="signin-button"
            disabled={isLoading}
          >
            {isLoading ? (
              <span>Signing In...</span>
            ) : (
              <>
                <span>Sign In</span>
                <ArrowRight size={20} />
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
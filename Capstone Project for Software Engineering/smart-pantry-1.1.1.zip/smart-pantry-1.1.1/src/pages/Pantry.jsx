"use client"
import React, { useState, useEffect } from "react"
import { Keyboard, Receipt, ScanBarcode, Mic, X, Plus, Trash2, Edit2 } from "lucide-react"
import BarcodeScanner from "../components/BarcodeScanner.jsx"
import ReceiptScanner from "../components/ReceiptScanner.jsx"
import MicrophoneInput from "../components/MicrophoneInput.jsx" 
import "./Pantry.css"
import supabase from '../supabase-client.js'
import { getUserId } from '../utils/userStorage.js'


export default function Pantry() {
  const [openAdd, setOpenAdd] = useState(false)
  const [selectedItem, setSelectedItem] = useState(null)
  const [pantryItems, setPantryItems] = useState([])
  const [itemFromShopping, setItemFromShopping] = useState(null)

  const userId = getUserId();

  // Check if there's an item coming from shopping list
  useEffect(() => {
    const storedItem = sessionStorage.getItem('itemToAdd');
    if (storedItem) {
      try {
        const itemData = JSON.parse(storedItem);
        setItemFromShopping(itemData);
        sessionStorage.removeItem('itemToAdd');
        setOpenAdd(true);
      } catch (err) {
        console.error('Failed to parse item from shopping list:', err);
        sessionStorage.removeItem('itemToAdd');
      }
    }
  }, []);

  // load items from Supabase
  function formatDateString(d) {
    try {
      if(!d) return 'Unknow'
      const s = String(d).trim()
      if(/^\d{4}-\d{2}-\d{2}/.test(s)){
        const [year,month, day] = s.split('T')[0].split('-')
        const date = new Date(parseInt(year), parseInt(month)-1, parseInt(day))
        if (isNaN(date.getTime())) return s
        return date.toLocaleDateString()
      }
      // accept Date or ISO string
      const date = d instanceof Date ? d : new Date(d)
      if (isNaN(date.getTime())) return String(d)
      return date.toLocaleDateString()
    } catch {
      return String(d)
    }
  }

  useEffect(() => {
    if(!userId) return;
    let mounted = true;
    (async () => {
      try {
        const { data, error } = await supabase
          .from('Pantry')
          .select('id, name, expir_date, amount_value, amount_unit')
          .eq('user_id', userId)
          .order('expir_date', { ascending: true })

        if (!error && mounted) {
          const mapped = (data || []).map((r) => ({
            id: r.id,
            name: r.name,
            quantity: r.amount_value != null ? `${r.amount_value} ${r.amount_unit || ''}`.trim() : (r.amount_unit || ''),
            expiry: r.expir_date ? formatDateString(r.expir_date) : 'Unknown',
            _raw: r,
          }))
          setPantryItems(mapped)
        }
      } catch (err) {
        if (mounted) console.error('Fetch pantry failed', err)
      }
    })();

    return () => { mounted = false }
  }, [userId])

  // ---------- SORTED VERSION ----------
  const sortedItems = [...pantryItems].sort(
    (a, b) => expiryToDays(a.expiry) - expiryToDays(b.expiry)
  )

  // update item
  const handleUpdate = async (idx, updated) => {
    // find current item and id
    const current = pantryItems[idx]
    if (!current) return

    // build payload for supabase
    const payload = buildDbPayloadFromUi(updated)

    try {
      const { data, error } = await supabase.from('Pantry').update(payload).eq('id', current.id).select()
      if (error) {
        console.error('Error updating item:', error)
      } else {
        // replace local item with returned data (map to UI shape)
        const r = data[0]
        const mapped = {
          id: r.id,
          name: r.name,
          quantity: r.amount_value != null ? `${r.amount_value} ${r.amount_unit || ''}`.trim() : (r.amount_unit || ''),
          expiry: r.expir_date ? formatDateString(r.expir_date) : 'Unknown',
          _raw: r,
        }
        setPantryItems((prev) => prev.map((it, i) => (i === idx ? mapped : it)))
      }
    } catch (err) {
      console.error('Update failed', err)
    }

    setSelectedItem(null)
  }

  // delete item
  const handleDelete = async (idx) => {
    const current = pantryItems[idx]
    if (!current) return

    try {
      const { error } = await supabase.from('Pantry').delete().eq('id', current.id)
      if (error) {
        console.error('Error deleting item:', error)
      } else {
        setPantryItems((prev) => prev.filter((_, i) => i !== idx))
      }
    } catch (err) {
      console.error('Delete failed', err)
    }

    setSelectedItem(null)
  }

  // add new item
  const handleAddItem = async (item, fromShoppingList = false) => {
    if(!userId){
      alert('User not signed in. Please sign in to add items to your pantry.')
      return;
    }
    // item has { name, quantity, expiry } from modal
    const payload = buildDbPayloadFromUi(item)
    payload.user_id = userId;
    // Store timestamp to help distinguish shopping list and pantry additions
    if (fromShoppingList) {
      // Add a small delay to ensure different timestamps
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    try {
      const { data, error } = await supabase.from('Pantry').insert([payload]).select()
      if (error) {
        console.error('Error inserting item:', error)
      } else {
        const r = data[0]
        const mapped = {
          id: r.id,
          name: r.name,
          quantity: r.amount_value != null ? `${r.amount_value} ${r.amount_unit || ''}`.trim() : (r.amount_unit || ''),
          expiry: r.expir_date ? formatDateString(r.expir_date) : 'Unknown',
          _raw: r,
        }
        setPantryItems((prev) => [mapped, ...prev])
      }
    } catch (err) {
      console.error('Insert failed', err)
    }

    setOpenAdd(false)
  }

  // Helpers to map UI fields to DB columns
  function buildDbPayloadFromUi(ui) {
    // ui: { name, quantity, expiry }
    const name = ui.name
    const { amount_value, amount_unit } = parseQuantity(ui.quantity || '')
    const expir_date = parseExpiryToDate(ui.expiry || '')
    return { name, amount_value, amount_unit, expir_date }
  }

  function parseQuantity(quantity) {
    // try to parse "2 kg" -> { amount_value: 2, amount_unit: 'kg' }
    if (!quantity) return { amount_value: null, amount_unit: null }
    const m = String(quantity).trim().match(/^\s*(\d+(?:\.\d+)?)\s*(.*)$/)
    if (m) {
      const val = Number(m[1])
      const unit = (m[2] || '').trim() || null
      return { amount_value: isNaN(val) ? null : val, amount_unit: unit }
    }
    // fallback: store whole string in unit for freeform quantities
    return { amount_value: null, amount_unit: String(quantity).trim() }
  }

  function parseExpiryToDate(expiry) {
    if (!expiry) return null
    const s = String(expiry).trim()
    // yyyy-mm-dd
    if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s

    // relative like "3 days", "1 week"
    const m = s.toLowerCase().match(/(\d+)\s*(day|week|month|year)/)
    if (m) {
      const num = parseInt(m[1], 10)
      const unit = m[2]
      const now = new Date()

      const year = now.getFullYear()
      const month = now.getMonth()
      const day = now.getDate()

      switch (unit) {
        case 'day': now.setDate(now.getDate() + num); break
        case 'week': now.setDate(now.getDate() + num * 7); break
        case 'month': now.setMonth(now.getMonth() + num); break
        case 'year': now.setFullYear(now.getFullYear() + num); break
      }

      const y = now.getFullYear()
      const mth = String(now.getMonth() + 1).padStart(2, '0')
      const d = String(now.getDate()).padStart(2, '0')
      return `${y}-${mth}-${d}`
    }

    return null
  }

  return (
    <div className="pantry-container">
      <div className="header">
        <div className="header-content">
          <p><span className="bold-text">{pantryItems.length}</span> items in pantry</p>
          <button className="btn small-btn" onClick={() => setOpenAdd(true)}>
            <Plus className="icon" />
            Add Item
          </button>
        </div>
      </div>

      {/* ---------- SORTED LIST ---------- */}
      <div className="items">
        {sortedItems.map((item, idx) => (
          <div
            key={idx}
            className="card"
            onClick={() => setSelectedItem({ ...item, idx })}
            style={{ cursor: "pointer" }}
          >
            <div className="card-left">
              <div>
                <h4>{item.name}</h4>
                <p>{item.quantity}</p>
              </div>
              <span
                className="expiry"
                style={{
                  backgroundColor: getExpiryColor(item.expiry),
                  color: "#fff",
                  padding: "4px 10px",
                  borderRadius: "12px",
                  fontWeight: "600",
                  fontSize: "0.8rem",
                }}
              >
                {item.expiry ? `Expires: ${item.expiry}` : "No expiry"}
              </span>
            </div>
          </div>
        ))}
      </div>

      {openAdd && <AddItemModal onClose={() => {
        setOpenAdd(false);
        setItemFromShopping(null);
      }} onAdd={handleAddItem} itemFromShopping={itemFromShopping} />}
      {selectedItem && (
        <ItemDetailModal
          item={selectedItem}
          onClose={() => setSelectedItem(null)}
          onDelete={() => handleDelete(selectedItem.idx)}
          onUpdate={(updated) => handleUpdate(selectedItem.idx, updated)}
        />
      )}
    </div>
  )
}

/* --------------------- AddItemModal --------------------- */
function AddItemModal({ onClose, onAdd, itemFromShopping }) {
  const inputMethods = [
    { id: "manual", icon: Keyboard, label: "Manual Input", description: "Type item details", color: "#CFE0FF" },
    { id: "receipt", icon: Receipt, label: "Receipt Scanner", description: "Scan a receipt", color: "#E2D4FF" },
    { id: "barcode", icon: ScanBarcode, label: "Barcode Scanner", description: "Scan product barcode", color: "#D4F5D4" },
    { id: "voice", icon: Mic, label: "Voice Input", description: "Say what you have", color: "#FFD4D9" },
  ];

  const [manualOpen, setManualOpen] = useState(!!itemFromShopping);
  const [scannerOpen, setScannerOpen] = useState(false);
  const [receiptOpen, setReceiptOpen] = useState(false);
  const [voiceOpen, setVoiceOpen] = useState(false); // Added state for voice input
  const [shoppingListId, setShoppingListId] = useState(itemFromShopping?.shoppingListId || null);
  // form includes freeform expiry text and optional expiry_date (yyyy-mm-dd)
  const [form, setForm] = useState({ 
    name: itemFromShopping?.name || "", 
    quantity: itemFromShopping ? 
      (itemFromShopping.amount_value != null ? 
        `${itemFromShopping.amount_value} ${itemFromShopping.amount_unit || ''}`.trim() : 
        (itemFromShopping.amount_unit || '')) : "",
    expiry: "", 
    expiry_date: "" 
  });

  const handleMethodClick = (id) => {
    if (id === "manual") {
      setManualOpen(true);
    } else if (id === "barcode") {
      setScannerOpen(true);
    } else if (id === "receipt") {
      setReceiptOpen(true);
    } else if (id === "voice") {
      setVoiceOpen(true); // Handle voice input
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name.trim()) return;

    // prefer explicit date if provided, otherwise use freeform expiry
    const chosenExpiry = (form.expiry_date || form.expiry || "").trim();

    const newItem = {
      name: form.name.trim(),
      quantity: form.quantity.trim() || "1",
      expiry: chosenExpiry || "Unknown",
    };

    onAdd(newItem, !!shoppingListId);
    
    // If this item came from shopping list, delete it from there
    if (shoppingListId) {
      try {
        await supabase.from('ShoppingList').delete().eq('id', shoppingListId);
      } catch (err) {
        console.error('Failed to remove item from shopping list:', err);
      }
    }
    
    setForm({ name: "", quantity: "", expiry: "", expiry_date: "" });
    setManualOpen(false);
    
    // If we came from shopping list, close the entire modal
    if (shoppingListId) {
      onClose();
    }
  };

  const handleBarcodeDetected = async (code) => {
    try {
      const productInfo = await fetchProductInfo(code);

      if (productInfo) {
        onAdd({
          name: productInfo.name,
          quantity: productInfo.quantity || "1",
          expiry: productInfo.expiry || "Unknown"
        });
      } else {
        onAdd({
          name: `Scanned Item (${code})`,
          quantity: "1",
          expiry: "Unknown"
        });
      }

      setScannerOpen(false);
      onClose();
    } catch (error) {
      onAdd({
        name: `Scanned Item (${code})`,
        quantity: "1",
        expiry: "Unknown"
      });
      setScannerOpen(false);
      onClose();
    }
  };

  const fetchProductInfo = async (barcode) => {
    const APIs = [
      {
        name: 'Open Food Facts',
        url: `https://world.openfoodfacts.org/api/v0/product/${barcode}.json`,
        parser: (data) => {
          if (data.status === 1 && data.product) {
            const p = data.product;
            return {
              name: p.product_name || p.product_name_en,
              quantity: p.quantity,
            };
          }
          return null;
        }
      },
      {
        name: 'UPCitemdb',
        url: `https://api.upcitemdb.com/prod/trial/lookup?upc=${barcode}`,
        parser: (data) => {
          if (data.items && data.items.length > 0) {
            const item = data.items[0];
            return {
              name: item.title,
              quantity: item.size || item.dimension,
            };
          }
          return null;
        }
      }
    ];

    for (const api of APIs) {
      try {
        const res = await fetch(api.url);
        if (res.ok) {
          const data = await res.json();
          const parsed = api.parser(data);
          if (parsed) return { ...parsed, expiry: "Unknown" };
        }
      } catch {}
    }

    return null;
  };

  // When receipt scanner returns items:
  const handleReceiptDetected = (items) => {
    // items is an array of { name, quantity, expiry }
    items.forEach((it) => {
      onAdd({
        name: it.name || "Unknown Item",
        quantity: it.quantity || "1",
        expiry: it.expiry || "Unknown"
      });
    });

    setReceiptOpen(false);
    onClose();
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>
            {scannerOpen ? "Scan Barcode" : manualOpen ? "Enter Item Details" : voiceOpen ? "Voice Input" : "Add Item to Pantry"}
          </h2>
          <button className="close-btn" onClick={onClose}><X /></button>
        </div>

        {scannerOpen && (
          <div className="scanner-modal-content">
            <div className="scanner-instructions">
              <p>Point your camera at a barcode to scan</p>
            </div>
            <div className="scanner-container">
              <div id="camera" className="camera-view"></div>
              <div className="scanning-line"></div>
            </div>
            <div className="modal-actions">
              <button
                className="btn btn-secondary"
                onClick={() => setScannerOpen(false)}
                style={{ marginTop: '20px' }}
              >
                Back
              </button>
            </div>

            <BarcodeScanner
              onDetected={handleBarcodeDetected}
              onClose={() => setScannerOpen(false)}
            />
          </div>
        )}

        {voiceOpen && (
          <MicrophoneInput
            onAdd={onAdd}
            onClose={() => setVoiceOpen(false)}
          />
        )}

        {!manualOpen && !scannerOpen && !receiptOpen && !voiceOpen && (
          <div className="modal-grid">
            {inputMethods.map((m) => {
              const Icon = m.icon;
              return (
                <button key={m.id} className="modal-card" onClick={() => handleMethodClick(m.id)}>
                  <div className="icon-circle" style={{ backgroundColor: m.color }}>
                    <Icon />
                  </div>
                  <span>{m.label}</span>
                  <span className="desc">{m.description}</span>
                </button>
              );
            })}
          </div>
        )}

        {receiptOpen && (
          <div>
            <ReceiptScanner
              onExtract={handleReceiptDetected}
              onClose={() => setReceiptOpen(false)}
            />
          </div>
        )}

        {manualOpen && !scannerOpen && !receiptOpen && !voiceOpen && (
          <form className="manual-form" onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Item Name</label>
              <input
                name="name"
                value={form.name}
                onChange={handleChange}
                placeholder="Bananas, Milk, Chicken"
                required
                className="form-input"
              />
            </div>

            <div className="form-group">
              <label>Quantity</label>
              <input
                name="quantity"
                value={form.quantity}
                onChange={handleChange}
                placeholder="6 pieces, 500g, 1L"
                className="form-input"
              />
            </div>

            <div className="form-group">
              <label>Expiry Date (picker)</label>
              <input
                name="expiry_date"
                type="date"
                value={form.expiry_date}
                onChange={handleChange}
                className="form-input"
              />
            </div>

            <div className="form-group">
              <label>Expiry (text)</label>
              <input
                name="expiry"
                value={form.expiry}
                onChange={handleChange}
                placeholder="3 days, 1 week, 2024-12-31"
                className="form-input"
              />
            </div>

            <div className="modal-actions modal-actions-stacked">
              <button type="button" className="btn btn-secondary" onClick={() => setManualOpen(false)}>
                Back
              </button>
              <button type="submit" className="btn btn-primary" disabled={!form.name.trim()}>
                Add
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

/* --------------------- ItemDetailModal --------------------- */
function ItemDetailModal({ item, onClose, onDelete, onUpdate }) {
  const [editOpen, setEditOpen] = useState(false)
  const [form, setForm] = useState({
    name: item.name,
    quantity: item.quantity,
    expiry: item.expiry,
    expiry_date: item._raw && item._raw.expir_date ? item._raw.expir_date : ""
  })

  const handleChange = (e) => {
    const { name, value } = e.target
    setForm((prev) => ({ ...prev, [name]: value }))
  }

  const handleSave = (e) => {
    e.preventDefault()
    if (!form.name.trim()) return

    const chosenExpiry = (form.expiry_date || form.expiry || "").trim()

    onUpdate({
      name: form.name.trim(),
      quantity: form.quantity.trim() || "1",
      expiry: chosenExpiry || "Unknown"
    })
    setEditOpen(false)
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal small-modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>{editOpen ? "Edit Item" : item.name}</h2>
          <button className="close-btn" onClick={onClose}><X /></button>
        </div>

        {!editOpen && (
          <>
            <div className="item-details">
              <div className="detail-row">
                <span className="detail-label">Quantity:</span>
                <span className="detail-value">{item.quantity}</span>
              </div>
              <div className="detail-row">
                <span className="detail-label">Expires:</span>
                <span className="detail-value">{item.expiry}</span>
              </div>
            </div>

            <div className="modal-actions modal-actions-stacked">
              <button className="btn btn-edit" onClick={() => setEditOpen(true)}>
                <Edit2 className="icon" /> Edit Item
              </button>
              <button className="btn btn-delete" onClick={onDelete}>
                <Trash2 className="icon" /> Delete Item
              </button>
            </div>
          </>
        )}

        {editOpen && (
          <form className="manual-form" onSubmit={handleSave}>
            <div className="form-group">
              <label>Item Name</label>
              <input
                name="name"
                value={form.name}
                onChange={handleChange}
                className="form-input"
              />
            </div>

            <div className="form-group">
              <label>Quantity</label>
              <input
                name="quantity"
                value={form.quantity}
                onChange={handleChange}
                className="form-input"
              />
            </div>

            <div className="form-group">
              <label>Expiry Date (picker)</label>
              <input
                name="expiry_date"
                type="date"
                value={form.expiry_date}
                onChange={handleChange}
                className="form-input"
              />
            </div>

            <div className="form-group">
              <label>Expiry (text)</label>
              <input
                name="expiry"
                value={form.expiry}
                onChange={handleChange}
                className="form-input"
              />
            </div>

            <div className="modal-actions">
              <button type="button" className="btn btn-secondary" onClick={() => setEditOpen(false)}>
                Cancel
              </button>
              <button type="submit" className="btn btn-primary">
                Save Changes
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  )
}

// ------------------ EXPIRY PARSER ------------------
function expiryToDays(expiry) {
  if (!expiry) return Infinity;

  const lower = expiry.toLowerCase().trim();

  // Case: date format yyyy-mm-dd
  if (/^\d{4}-\d{2}-\d{2}$/.test(lower)) {
    const now = new Date();
    const date = new Date(lower);
    const diff = (date - now) / (1000 * 60 * 60 * 24);
    return diff;
  }

  // Case: "3 days", "1 week", etc.
  const match = lower.match(/(\d+)\s*(day|week|month|year)/);
  if (!match) return Infinity;

  const num = parseInt(match[1], 10);
  const unit = match[2];

  switch (unit) {
    case "day": return num;
    case "week": return num * 7;
    case "month": return num * 30;
    case "year": return num * 365;
    default: return Infinity;
  }
}

function getExpiryColor(expiry) {
  const days = expiryToDays(expiry);

  if (days <= 2) return "#ff6b6b";      // red (urgent)
  if (days <= 7) return "#ffd93d";      // yellow (soon)
  if (days < Infinity) return "#6bcB77"; // green (safe)

  return "#cccccc"; // gray for Unknown / long times
}
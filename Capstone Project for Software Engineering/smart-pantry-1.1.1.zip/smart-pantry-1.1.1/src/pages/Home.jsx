import './Home.css';
import { useState, useEffect } from 'react';
import supabase from '../supabase-client.js';
import { getUserId } from '../utils/userStorage.js';

export default function Home() {
  return(
    <Body />
  );
}

function Body(){
  // Get user data to pass to components
  let user = null
  if (typeof window !== 'undefined') {
    try {
      const stored = localStorage.getItem('sp_user')
      if (stored) user = JSON.parse(stored)
    } catch (e) {
      user = null
    }
  }

  const capitalizedName = user?.name ? user.name.charAt(0).toUpperCase() + user.name.slice(1) : '';

  return(
    <div className = "home-body">
      {user && (
        <div className="welcome-message">
          Welcome back, {<i>{capitalizedName}</i>}!
        </div>
      )}
      <div className = "quick-actions">
        <ExpiringItems />
        <RecentActivity />
      </div>
      
    </div>
  )
}

function ExpiringItems() {
  const [expiringItems, setExpiringItems] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const userId = getUserId();

  useEffect(() => {
    if (!userId) {
      setIsLoading(false);
      return;
    }

    const fetchExpiringItems = async () => {
      try {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        const sevenDaysFromNow = new Date();
        sevenDaysFromNow.setDate(sevenDaysFromNow.getDate() + 7);
        sevenDaysFromNow.setHours(23, 59, 59, 999);
        
        const { data, error } = await supabase
          .from('Pantry')
          .select('name, expir_date')
          .eq('user_id', userId)
          .gte('expir_date', today.toISOString())
          .lte('expir_date', sevenDaysFromNow.toISOString())
          .order('expir_date', { ascending: true })
          .limit(5);

        if (!error && data) {
          setExpiringItems(data);
        }
      } catch (err) {
        console.error('Error fetching expiring items:', err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchExpiringItems();
  }, [userId]);


  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    date.setHours(0, 0, 0, 0);
    
    const diffTime = date - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Tomorrow';
    return `in ${diffDays} days`;
  };

  return (
    <div className="expiring-items">
        <div className="card-header" style = {{backgroundColor: 'red'}}>
          Expiring Soon
        </div>
        <div className = "items-list">
          {isLoading ? (
            <div className="empty-state">Loading...</div>
          ) : expiringItems.length === 0 ? (
            <div className="empty-state">No items expiring soon</div>
          ) : (
            expiringItems.map((item, index) => (
              <div key={index} className="expire-item">
                <span className="item-name">{item.name}</span>
                <span className="item-expiry">{formatDate(item.expir_date)}</span>
              </div>
            ))
          )}
        </div>
    </div>
  );
}

function RecentActivity(){
  const [recentActivities, setRecentActivities] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const userId = getUserId();

  useEffect(() => {
    if (!userId) {
      setIsLoading(false);
      return;
    }

    const fetchRecentActivities = async () => {
      try {
        // Fetch from both Pantry and ShoppingList
        const [pantryResult, shoppingResult] = await Promise.all([
          supabase
            .from('Pantry')
            .select('name, created_at')
            .eq('user_id', userId)
            .order('created_at', { ascending: false })
            .limit(10),
          supabase
            .from('ShoppingList')
            .select('name, created_at')
            .eq('user_id', userId)
            .order('created_at', { ascending: false })
            .limit(10)
        ]);

        const activities = [];
        
        if (pantryResult.data) {
          pantryResult.data.forEach(item => {
            activities.push({
              name: item.name,
              type: 'pantry',
              timestamp: item.created_at
            });
          });
        }

        if (shoppingResult.data) {
          shoppingResult.data.forEach(item => {
            activities.push({
              name: item.name,
              type: 'shopping',
              timestamp: item.created_at
            });
          });
        }

        // Sort by timestamp and take the 5 most recent
        activities.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
        setRecentActivities(activities.slice(0, 5));
      } catch (err) {
        console.error('Error fetching recent activities:', err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchRecentActivities();
  }, [userId]);

  return (
    <div className="recent-activity">
      <div className="card-header" style = {{backgroundColor: 'rgb(65, 144, 26)'}}>
        Recent Activity
      </div>
      <div className="items-list">
        {isLoading ? (
          <div className="empty-state">Loading...</div>
        ) : recentActivities.length === 0 ? (
          <div className="empty-state">No recent activity</div>
        ) : (
          recentActivities.map((activity, index) => (
            <div key={index} className="activity-item">
              <div className="activity-info">
                <span className="activity-name">{activity.name}</span>
                <span className="activity-type">
                  {activity.type === 'pantry' ? 'Added to Pantry' : 'Added to Shopping List'}
                </span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
















import './App.css';
import { BrowserRouter as Router, Routes, Route, Link, useLocation, Navigate } from 'react-router-dom';
import Home from './pages/Home.jsx';
import Pantry from './pages/Pantry';
import ShoppingList from './pages/ShoppingList';
import Recipes from './pages/Recipes.jsx';
import Profile from './pages/Profile.jsx';
import SignIn from './pages/SignIn.jsx';
import { Home as HomeIcon, ShoppingCart, ChefHat, User, Refrigerator } from "lucide-react";
import { useEffect, useState } from 'react';
import { getCurrentUser } from './utils/userStorage.js';

function ProtectedRoute({ children }){
  const[isAuthenticated, setIsAuthenticated] = useState(null);
  useEffect(() => {
    const user = localStorage.getItem('sp_user');
    setIsAuthenticated(!!user);   
  }, []);
  if (isAuthenticated === null) {
    return <div>Loading...</div>;
  }

  return isAuthenticated ? children : <Navigate to="/signin" replace />;
}

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path ="/signin" element={<SignIn />} />
        <Route path="/*" element={
          <ProtectedRoute>
            <AuthenticatedApp />
          </ProtectedRoute>
        } />
      </Routes>
    </Router>
  );

}

function AuthenticatedApp(){
   const [profilePicture, setProfilePicture] = useState('/images/profile-picture.png');

  useEffect(() => {
    // Load initial profile picture
    const user = getCurrentUser();
    if (user?.profilePicture) {
      setProfilePicture(user.profilePicture);
    }

    const handleStorageChange = () => {
      const updatedUser = getCurrentUser();
      if (updatedUser?.profilePicture) {
        setProfilePicture(updatedUser.profilePicture);
      }
    };

    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('profilePictureUpdated', handleStorageChange);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('profilePictureUpdated', handleStorageChange);
    };
  }, [setProfilePicture]);

  return(
    <>
    <Header profilePicture={profilePicture} />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/pantry" element={<Pantry />} />
        <Route path="/shopping" element={<ShoppingList />} />
        <Route path="/recipes" element={<Recipes />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
      <NavBar />
      </>
  );

}

function Header({ profilePicture }) {
   return (
    <header className="app-header">
        <Link to ="/" className = "logo-link">
          <img src="/images/logo.png" className="logo"/>
        </Link>
        <text className="header-text">
          Smart <span style={{ color: '#f4137fff' }}>Pantry</span>
        </text>
        <Link to ="/profile" className="profile-link" >
        <img src={profilePicture} className="profile-picture" alt="Profile" />
        </Link>
    </header>
  );
}

function NavBar() {

  const location = useLocation();
  const isActive = (path) => location.pathname === path;
  return (
    <nav className="nav-bar">
      <div className="container-fluid">
        <Link to="/" className={`nav-item ${isActive('/') ? "nav-item-active": ""}`}>
          <HomeIcon className="nav-icon" size={22} />
          <span className="nav-label">Home</span>
        </Link>
        <Link to="/pantry" className={`nav-item ${isActive('/pantry') ? "nav-item-active": ""}`}>
          <Refrigerator className="nav-icon" size={22} />
          <span className="nav-label">Pantry</span>
        </Link>
        <Link to="/shopping" className={`nav-item ${isActive('/shopping') ? "nav-item-active": ""}`}>
          <ShoppingCart className="nav-icon" size={22} />
          <span className="nav-label">List</span>
        </Link>
        <Link to="/recipes" className={`nav-item ${isActive('/recipes') ? "nav-item-active": ""}`}>
          <ChefHat className="nav-icon" size={22} />
          <span className="nav-label">Recipes</span>
        </Link>
        <Link to="/profile" className={`nav-item ${isActive('/profile') ? "nav-item-active": ""}`}>
          <User className="nav-icon" size={22} />
          <span className="nav-label">Profile</span>
        </Link>
      </div>
    </nav>
  );
}

function NotFound() {
  return (
    <main className="page">
      <h1>Page not found</h1>
      <p>Try one of the links above.</p>
    </main>
  );
}

import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import App from './App';

test('renders learn react link', () => {
  render(<App />);
  const titleElement = screen.getByText(/Recipe Book/i);
  expect(titleElement).toBeInTheDocument();
});

// test that checks if title renders
test('renders title', () => {
  render(<App />);
  const titleElement = screen.getByText(/Recipe Book/i);
  expect(titleElement).toBeInTheDocument();
});

//test that checks if body text renders
test('renders body text', () => {
  render(<App />);
  const bodyElement = screen.getByText(/Featured Recipes/i);
  expect(bodyElement).toBeInTheDocument();
});

//test that checks if image in recipe card 5 renders
test('renders image in recipe card 5', () => {
  render(<App />);
  const recipeElement = screen.getByAltText(/Recipe 5/i);
  expect(recipeElement).toBeInTheDocument();
});

test('renders navbar', () => {
  const { container } = render(<App />);
  const recipeElement = screen.getAllByText('Home')[0];
  expect(recipeElement).toBeInTheDocument();
});

test('renders recipe card', () => {
  const { container } = render(<App />);
  const recipeElement = screen.getAllByText('Omelette')[0];
  expect(recipeElement).toBeInTheDocument();
});

// test that checks if after clicking on a recipe card, the recipe details page renders
test('renders recipe details page', () => {
  const { container } = render(<App />);
  const recipeElement = screen.getAllByText('Omelette')[0];
  fireEvent.click(recipeElement);
  const recipeDetailsElement = screen.getByText(/Ingredients/i);
  expect(recipeDetailsElement).toBeInTheDocument();
});
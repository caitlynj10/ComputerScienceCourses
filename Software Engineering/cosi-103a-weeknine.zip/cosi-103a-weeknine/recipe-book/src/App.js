
  import './App.css';
  import Omelette from './pages/Omelette.js';
  import Salmon from './pages/Salmon.js';
  import Sorbet from './pages/Sorbet.js';
  import Ramen from './pages/Ramen.js';
  import Pie from './pages/Pie.js';
  import TortillaSoup from './pages/TortillaSoup.js';
  import Enchiladas from './pages/Enchiladas.js';
  import Team from './pages/Team.js';
  import GroceryList from './pages/GroceryList.js';
  import SubmitRecipes from './pages/SubmitRecipes.js';
  import AllRecipes from './pages/AllRecipes.js';
  import {Link} from 'react-router-dom';

  import { BrowserRouter as Router, Routes, Route, useLocation} from 'react-router-dom';

  export default function App() {
    
    return (
     <Router>
       <Header/>
       <HomeBar/>
       <Routes>
        <Route path="/Omelette" element={<Omelette/>} />
        <Route path="/Salmon" element={<Salmon/>} />
        <Route path="/Sorbet" element={<Sorbet/>} />
        <Route path="/Ramen" element={<Ramen/>} />
        <Route path="/Pie" element={<Pie/>} />
        <Route path="/TortillaSoup" element={<TortillaSoup/>} />
        <Route path="/Enchiladas" element={<Enchiladas/>} />
        <Route path="/Team" element={<Team/>} />
        <Route path="/GroceryList" element={<GroceryList/>} />
        <Route path="/SubmitRecipes" element={<SubmitRecipes/>} />
        <Route path="/AllRecipes" element={<AllRecipes/>} />
      </Routes>
      <Display/>
      
     </Router>


    );
  }
  function Display() {
    const location = useLocation();
    return (
      <>
        {location.pathname === '/' && <Body />}
        {/* ... other components or content based on route ... */}
      </>
    );
  }

  function Header(){
    return(
      <header className="header">
        <Link to="/" className="link-container">
        <img className="header-img" src='/apple-touch-icon.png' alt=""></img>
        </Link>
        <text className="text-style">
            Recipe Book
        </text>
      
      </header>
  
    )
  }

  function HomeBar(){
    return(
      <nav className="navbar">
    <div className="container-fluid">
      
      <Link to="/" className="body-text link navbar-option">Home</Link>
      <Link to="/Team" className="body-text link navbar-option">Team</Link>
      <Link to="/GroceryList" className="body-text link navbar-option">Grocery List</Link>
      <Link to ="/AllRecipes" className="body-text link navbar-option">All Recipes</Link>
      <Link to="/SubmitRecipes" className="body-text link navbar-option">Submit Recipes</Link>
    </div>
  </nav>
    )
  }

  function Body(){ 
    return(
    <div>
      <text className="body-text2">
        Featured Recipes
        </text>
      <div className="col">
      <div className="row">
        <Recipe1/>
        <Recipe2/>
        <Recipe3/>
      </div>
      <div className="row">
        <Recipe4/>
        <Recipe5/>
        <Recipe6/>
      </div>
      <div className="row">
        <Recipe7/>
      </div>

      </div>
    
      </div>
    )
  }

  function Recipe1(){
    return(
      <div>
      <div className="card">
      <img className="card-img1" src="https://www.simplyrecipes.com/thmb/9QGpG8qH0VODPhc7sQKj9vN3Cvo=/750x0/filters:no_upscale():max_bytes(150000):strip_icc():format(webp)/__opt__aboutcom__coeus__resources__content_migration__simply_recipes__uploads__2018__10__HT-Make-an-Omelet-LEAD-HORIZONTAL-17cd2e469c4a4ccbbd1273a7cae6425c.jpg" alt="Recipe 1"></img>
      </div>
      <Link to="/Omelette" className="card-title"> Omelette</Link>
      </div>
    )
  }
  
  function Recipe2(){
    return(
        <div>
        <div className="card">
        <img className="card-img2" src="https://cafedelites.com/wp-content/uploads/2017/03/Best-Crispy-Lemon-Garlic-Herb-Salmon-IMAGES-5.jpg" alt="Recipe 2"></img>
        </div>
        <Link to="/Salmon" className="card-title"> Butter Pan-Seared Salmon</Link>
        </div>
      )
  }
  
  function Recipe3(){
    return(
      <div>
      <div className="card">
      <img className="card-img3" src="https://www.tasteofhome.com/wp-content/uploads/2019/10/Quick-Mango-Passion-Fruit-Sorbet_EXPS_TOHFM20_238674_B09_20_3b-4.jpg?fit=696,696" alt="Recipe 3"></img>
      </div>
      <Link to="/Sorbet" className="card-title"> Mango Sorbet</Link>
      </div>
      )
  }
  
  function Recipe4(){
    return(
      <div>
        <div className="card">
        <img className="card-img4" src="https://images.themodernproper.com/billowy-turkey/production/posts/2020/Sesame-Garlic-Noodles-12.jpg?w=1800&q=82&fm=jpg&fit=crop&dm=1600181497&s=e8e6f06bb16fe0b593c401d703899e9f" alt="Recipe 4"></img>
        </div>
        <Link to="/Ramen" className="card-title"> Sesame Garlic Ramen</Link>
      </div>
      )
  }
  


  function Recipe5(){
    return(
      <div>
        <div className="card">
          <img className="card-img1" src="https://www.verybestbaking.com/sites/g/files/jgfbjl326/files/srh_recipes/fc8dd36d74da6068246e24b3547c5afb.jpg" alt="recipe 5"/>
        <div className="card-img-overlay">
        </div>
        </div>
        <Link to="/Pie" className="card-title"> Pumpkin Pie</Link>   
      </div>
      )
  }




  function Recipe6(){
    return(
      <div>
      <div className="card">
      <img className="card-img2" src="https://www.jerseygirlcooks.com/wp-content/uploads/2010/03/tortilla-soup-FB.jpg " alt="recipe 6"/>
        <div className="card-img-overlay">
      </div>
      </div>
      <Link to="/TortillaSoup" className="card-title">Chicken Tortilla Soup</Link>         
      </div>
      )
  }

  function Recipe7(){
    return(
      <div>
      <div className="card">
      <img className="card-img3" src="https://hips.hearstapps.com/hmg-prod/images/enchiladas-verdes-recipe-2-1659537049.jpg?crop=0.6666666666666667xw:1xh;center,top&resize=1200:*" alt="recipe 7"/>
        <div className="card-img-overlay">
      </div>
      </div>
      <Link to="/Enchiladas" className="card-title">Enchiladas Verdes</Link>      
      </div>
      )
  }
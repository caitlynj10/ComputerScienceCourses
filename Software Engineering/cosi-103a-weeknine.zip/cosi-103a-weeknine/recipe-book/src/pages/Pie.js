import React, {useState, useEffect} from 'react';
import './recipes.css';
import {useNavigate} from 'react-router-dom';

export default function Pie() {
    return (
     <>
    <RecipeDetails/>
    </>
    );
  
}
  function RecipeDetails(){
    const [checkedItems, setCheckedItems] = useState([]);
    const navigate = useNavigate();

    const handleCheckbox = (event) => {
     const {name, checked} = event.target;

     setIngredients(ingredients =>
      ingredients.map(ingredient =>
        ingredient.name === name ? { ...ingredient, checked: checked } : ingredient
      )
    );

     setCheckedItems((prev) => {
        if(checked){
          return [...prev, name];
        }
        else{
          return prev.filter((item) => item !== name);
        }
      });
    };

    const goToGroceryList = () => {
      const savedItems = localStorage.getItem('items');
      const allItems = savedItems ? [...JSON.parse(savedItems), ...checkedItems] : checkedItems;  
      localStorage.setItem('items', JSON.stringify(allItems));
      navigate('../GroceryList');
    }

    const [isOpen, setIsOpen] = useState(false);
    const togglePopup = () => {
      setIsOpen(!isOpen);
    } 
    const [ingredients, setIngredients] = useState([
      {name: "15 oz pumpkin puree", fullName: "1 15 ounce can pumpkin puree", checked: false, id: 0},
      {name: "14 oz Eagle Brand Sweetened Condensed Milk", fullName: "1 14 ounce can Eagle Brand Sweetened Condensed Milk", checked: false, id: 0},
      {name: "2 Large Eggs", fullName: "2 large eggs", checked: false, id: 0},
      {name: "Ground Cinnamon", fullName: "1 teaspoon ground cinnamon", checked: false, id: 0},
      {name: "Ground Ginger", fullName: "½ teaspoon ground ginger", checked: false, id: 0},
      {name: "Ground Nutmeg", fullName: "½ teaspoon ground nutmeg", checked: false, id: 0},
      {name: "Salt", fullName: "½ teaspoon salt", checked: false, id: 0},
      {name: "9 inch unbaked pie crust", fullName: "1 (9 inch) unbaked pie crust", checked: false, id: 0}
    ]);
  
    useEffect(() => {
      const updateIngredientIds = async () => {
        const apiKey = process.env.REACT_APP_API_KEY; // Moved inside the function for clarity
        console.log(apiKey);
        const updatedIngredients = await Promise.all(ingredients.map(async (ingredient) => {
          const baseUrl = `https://api.nal.usda.gov/fdc/v1/foods/search?api_key=${apiKey}`;
          const queryUrl = `${baseUrl}&query=${encodeURIComponent(ingredient.name)}`;
  
          try {
            const response = await fetch(queryUrl);
            if (!response.ok) {
              throw new Error(`API call failed: ${response.status}`);
            }
            const data = await response.json();
            if (data.foods && data.foods.length > 0) {
              const id = data.foods[0].fdcId;
              return { ...ingredient, id }; // Return a new ingredient object with the updated ID
            } else {
              console.log(`No results found for ${ingredient.name}`);
              return ingredient; // Return the original ingredient if no ID is found
            }
          } catch (error) {
            console.error(`Failed to fetch ID for ${ingredient.name}:`, error);
            return ingredient; // Return the original ingredient in case of error
          }
        }));
  
        setIngredients(updatedIngredients); // Update the state once with all updated ingredients
      };
  
      updateIngredientIds();
      // Removed ingredients from the dependency array to prevent re-triggering
    }, [ingredients]);

    return(
      <div>
       
        <text className="recipe-text">Pumpkin Pie</text>
        <p className="details-text">
      Enjoy a classic pumpkin pie recipe that is perfect for the fall season.
      </p>
        <div className="img-container">
        <img className="img1" src="https://www.verybestbaking.com/sites/g/files/jgfbjl326/files/srh_recipes/fc8dd36d74da6068246e24b3547c5afb.jpg" alt="recipe 5"/>
        </div>
       
      <div className='card-container'>
      <div className="card2">
      <p className="recipe-body-text">
        Ingredients
        </p>
      <p className="recipe-details-text">
      {ingredients.map((ingredient, index) => {
              return (
                <label key={index}>
                  <input type="checkbox" name={ingredient.name} onChange={handleCheckbox} />
                  <a href={`https://fdc.nal.usda.gov/fdc-app.html#/food-details/${ingredient.id}/nutrients`}>
                      {ingredient.fullName}
                    </a>
                  <br />
                  {ingredient.id}
                  <br />
                </label>
              );
            })}

        <button className="grocery-button" onClick={goToGroceryList}>Add to Grocery List</button>

      </p>
      <p className="recipe-body-text">
        Directions
        <br />  
        <button className="cooking-button" onClick = {togglePopup}> Cooking Mode</button>
      {isOpen && (
        <div className="popup">
          <button className="close-button" onClick={togglePopup}>X</button>
          <div> 
          <p className="popup-text">
          1.  Preheat oven to 425 degrees F<br />
         <br />
        2.  Whisk pumpkin, sweetened condensed milk, eggs, spices and salt in medium bowl until smooth. Pour into crust. Bake 15 minutes.<br />
        <br />
        3.  Reduce oven temperature to 350 degrees F and continue baking 35 to 40 minutes or until knife inserted 1 inch from crust comes out clean. <br />
        <br />
        4.  Cool. Garnish as desired. Store leftovers covered in refrigerator.<br />
        <br />
          </p>
          </div>
        </div>

      )}
      </p>
      <p className="recipe-details-text">
        1.  Preheat oven to 425 degrees F<br />
         <br />
        2.  Whisk pumpkin, sweetened condensed milk, eggs, spices and salt in medium bowl until smooth. Pour into crust. Bake 15 minutes.<br />
        <br />
        3.  Reduce oven temperature to 350 degrees F and continue baking 35 to 40 minutes or until knife inserted 1 inch from crust comes out clean. <br />
        <br />
        4.  Cool. Garnish as desired. Store leftovers covered in refrigerator.<br />
        <br />
      </p>
      </div>

      </div>

      </div>
    )
  }

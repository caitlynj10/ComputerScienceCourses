import React, { useState, useEffect} from 'react';
import './recipes.css';
import {useNavigate} from 'react-router-dom';

export default function Ramen() {
    return (
     <>
    <RecipeDetails/>
    </>
    );
  
    }

  function RecipeDetails(){
    const [checkedItems, setCheckedItems] = useState([]);
    const navigate = useNavigate();

    const handleCheckbox = (event) => {
     const {name, checked} = event.target;

     setIngredients(ingredients =>
      ingredients.map(ingredient =>
        ingredient.name === name ? { ...ingredient, checked: checked } : ingredient
      )
    );

     setCheckedItems((prev) => {
        if(checked){
          return [...prev, name];
        }
        else{
          return prev.filter((item) => item !== name);
        }
      });
    };

    const goToGroceryList = () => {
      const savedItems = localStorage.getItem('items');
      const allItems = savedItems ? [...JSON.parse(savedItems), ...checkedItems] : checkedItems;  
      localStorage.setItem('items', JSON.stringify(allItems));
      navigate('../GroceryList');

    }

      
    const [isOpen, setIsOpen] = useState(false);
    const togglePopup = () => {
      setIsOpen(!isOpen);
    } 

    const [ingredients, setIngredients] = useState([
      {name: "3 3 oz Instant Ramen Noodle Packages", fullName: "3 (3 oz) packages instant ramen noodles, flavor packets discarded", checked: false, id: 0},
      {name: "Low Sodium Soy Sauce", fullName: "1/4 cup low sodium soy sauce", checked: false, id: 0},
      {name: "Oyster Sauce", fullName: "1/4 cup oyster sauce or hoisin sauce if vegetarian", checked: false, id: 0},
      {name: "Rice Vinegar", fullName: "1 tbsp rice vinegar", checked: false, id: 0},
      {name: "Brown Sugar", fullName: "1 tbsp brown sugar, optional", checked: false, id: 0},
      {name: "Chili Sauce", fullName: "½ -1 tsp chili sauce like sambal or sriracha", checked: false, id: 0},
      {name: "Water", fullName: "¼ cup water", checked: false, id: 0},
      {name: "Toasted Sesame Oil", fullName: "2 tbsp toasted sesame oil", checked: false, id: 0},
      {name: "4 Garlic Cloves", fullName: "4 cloves garlic, minced about 2 tsp", checked: false, id: 0},
      {name: "Freshly Grated Ginger", fullName: "1 tsp freshly grated ginger", checked: false, id: 0},
      {name: "Green Onions", fullName: "4-6 green onions, thinly sliced", checked: false, id: 0},
      {name: "Sesame Seeds", fullName: "1 tsp sesame seeds", checked: false, id: 0},
    ]);
  
    useEffect(() => {
      const updateIngredientIds = async () => {
        const apiKey = process.env.REACT_APP_API_KEY; // Moved inside the function for clarity
        console.log(apiKey);
        const updatedIngredients = await Promise.all(ingredients.map(async (ingredient) => {
          const baseUrl = `https://api.nal.usda.gov/fdc/v1/foods/search?api_key=${apiKey}`;
          const queryUrl = `${baseUrl}&query=${encodeURIComponent(ingredient.name)}`;
  
          try {
            const response = await fetch(queryUrl);
            if (!response.ok) {
              throw new Error(`API call failed: ${response.status}`);
            }
            const data = await response.json();
            if (data.foods && data.foods.length > 0) {
              const id = data.foods[0].fdcId;
              return { ...ingredient, id }; // Return a new ingredient object with the updated ID
            } else {
              console.log(`No results found for ${ingredient.name}`);
              return ingredient; // Return the original ingredient if no ID is found
            }
          } catch (error) {
            console.error(`Failed to fetch ID for ${ingredient.name}:`, error);
            return ingredient; // Return the original ingredient in case of error
          }
        }));
  
        setIngredients(updatedIngredients); // Update the state once with all updated ingredients
      };
  
      updateIngredientIds();
      // Removed ingredients from the dependency array to prevent re-triggering
    }, [ingredients]);

    return(
      <div>
       
        <text className="recipe-text">Sesame Garlic Ramen</text>
        <p className="details-text">
      This savory sesame garlic ramen makes for a delicious and delectable dinner.  
      </p>
        <div className='img-container'>
        <img className="img1" src="https://images.themodernproper.com/billowy-turkey/production/posts/2020/Sesame-Garlic-Noodles-12.jpg?w=1800&q=82&fm=jpg&fit=crop&dm=1600181497&s=e8e6f06bb16fe0b593c401d703899e9f" alt="Recipe 4"></img>
        </div>

      <div className='card-container'>
      <div className="card2">
      <p className="recipe-body-text">
        Ingredients
        </p>
      <p className="recipe-details-text">
      {ingredients.map((ingredient, index) => {
              return (
                <label key={index}>
                  <input type="checkbox" name={ingredient.name} onChange={handleCheckbox} />
                  <a href={`https://fdc.nal.usda.gov/fdc-app.html#/food-details/${ingredient.id}/nutrients`}>
                      {ingredient.fullName}
                  </a>
                  <br />
                  {ingredient.id}
                  <br />
                </label>
              );
            })}
      <button className="grocery-button" onClick={goToGroceryList}>Add to Grocery List</button>
      
      </p>
      <p className="recipe-body-text">
        Directions
        <br />  
        <button className="cooking-button" onClick = {togglePopup}> Cooking Mode</button>
      {isOpen && (
        <div className="popup">
          <button className="close-button" onClick={togglePopup}>X</button>
          <div> 
          <p className="popup-text">
          1. In a large pot of boiling water, cook ramen according to package, about 3-4 minutes; drain well.<br />
        <br />
        2. In a small bowl, whisk together soy sauce, oyster sauce, rice vinegar, brown sugar, chili sauce and water.<br />
        <br />
        3. Heat sesame oil in a large skillet set over medium heat.<br />
        <br />
        4. Stir in garlic and ginger until fragrant, about 1 minute.<br />
        <br />
        5. Pour in the bowl of sauce and simmer for 3-4 minutes. Stir in cooked ramen noodles until heated through and evenly coated in sauce, about 3 minutes.<br />
        <br />
        6. Garnish with green onions and sesame seeds.<br />
        <br /> 
          </p>
          </div>
        </div>

      )}
      </p>
      <p className="recipe-details-text">
      1. In a large pot of boiling water, cook ramen according to package, about 3-4 minutes; drain well.<br />
        <br />
        2. In a small bowl, whisk together soy sauce, oyster sauce, rice vinegar, brown sugar, chili sauce and water.<br />
        <br />
        3. Heat sesame oil in a large skillet set over medium heat.<br />
        <br />
        4. Stir in garlic and ginger until fragrant, about 1 minute.<br />
        <br />
        5. Pour in the bowl of sauce and simmer for 3-4 minutes. Stir in cooked ramen noodles until heated through and evenly coated in sauce, about 3 minutes.<br />
        <br />
        6. Garnish with green onions and sesame seeds.<br />
        <br /> 
      </p>
      </div>
      </div>

      </div>
    )
  }

import React, { useState, useEffect } from 'react';
import './recipes.css';
import { useNavigate } from 'react-router-dom';

export default function Omlette() {

  return (
    <>
      <RecipeDetails />
    </>
  );

}


function RecipeDetails() {
  const [checkedItems, setCheckedItems] = useState([]);
  const navigate = useNavigate();

  const handleCheckbox = (event) => {
    const { name, checked } = event.target;

    setIngredients(ingredients =>
      ingredients.map(ingredient =>
        ingredient.name === name ? { ...ingredient, checked: checked } : ingredient
      )
    );

    setCheckedItems((prev) => {
      if (checked) {
        return [...prev, name];
      }
      else {
        return prev.filter((item) => item !== name);
      }
    });
  };

  const goToGroceryList = () => {
    const savedItems = localStorage.getItem('items');
    const allItems = savedItems ? [...JSON.parse(savedItems), ...checkedItems] : checkedItems;
    localStorage.setItem('items', JSON.stringify(allItems));
    navigate('../GroceryList');

  }

  const [isOpen, setIsOpen] = useState(false);
  const togglePopup = () => {
    setIsOpen(!isOpen);
  }

  const [ingredients, setIngredients] = useState([
    { name: "2 Large Eggs", fullName: "2 large eggs", checked: false, id: 0 },
    { name: "Salt", fullName: "Pinch of salt", checked: false, id: 0 },
    { name: "Butter", fullName: "1 tablespoon unsalted butter", checked: false, id: 0 },
    { name: "Desired Cheese", fullName: "2 tablespoons grated cheese, any kind", checked: false, id: 0 },
    { name: "Cherry tomatoes", fullName: "3 to 4 cherry tomatoes, cut in half and sprinkled lightly with salt", checked: false, id: 0 },
    { name: "Desired herb", fullName: "2 tablespoons chopped basil, parsley, or herb of your choice", checked: false, id: 0 }
  ]);

  useEffect(() => {
    const updateIngredientIds = async () => {
      const apiKey = process.env.REACT_APP_API_KEY; // Moved inside the function for clarity
      console.log(apiKey);
      const updatedIngredients = await Promise.all(ingredients.map(async (ingredient) => {
        const baseUrl = `https://api.nal.usda.gov/fdc/v1/foods/search?api_key=${apiKey}`;
        const queryUrl = `${baseUrl}&query=${encodeURIComponent(ingredient.name)}`;

        try {
          const response = await fetch(queryUrl);
          if (!response.ok) {
            throw new Error(`API call failed: ${response.status}`);
          }
          const data = await response.json();
          if (data.foods && data.foods.length > 0) {
            const id = data.foods[0].fdcId;
            return { ...ingredient, id }; // Return a new ingredient object with the updated ID
          } else {
            console.log(`No results found for ${ingredient.name}`);
            return ingredient; // Return the original ingredient if no ID is found
          }
        } catch (error) {
          console.error(`Failed to fetch ID for ${ingredient.name}:`, error);
          return ingredient; // Return the original ingredient in case of error
        }
      }));

      setIngredients(updatedIngredients); // Update the state once with all updated ingredients
    };

    updateIngredientIds();
    // Removed ingredients from the dependency array to prevent re-triggering
  }, [ingredients]);

  return (
    <div>

      <text className="recipe-text">Omelette</text>
      <p className="details-text">
        This light and fluffy omelette is perfect for breakfast.
      </p>
      <div className='img-container'>
        <img className="img1" src="https://www.simplyrecipes.com/thmb/9QGpG8qH0VODPhc7sQKj9vN3Cvo=/750x0/filters:no_upscale():max_bytes(150000):strip_icc():format(webp)/__opt__aboutcom__coeus__resources__content_migration__simply_recipes__uploads__2018__10__HT-Make-an-Omelet-LEAD-HORIZONTAL-17cd2e469c4a4ccbbd1273a7cae6425c.jpg" alt="Recipe 1"></img>
      </div>


      <div className='card-container'>
        <div className="card2">
          <p className="recipe-body-text">

            Ingredients
          </p>
          <p className="recipe-details-text">
            {ingredients.map((ingredient, index) => {
              return (
                <label key={index}>
                  <input type="checkbox" name={ingredient.name} onChange={handleCheckbox} />
                  <a href={`https://fdc.nal.usda.gov/fdc-app.html#/food-details/${ingredient.id}/nutrients`}>
                      {ingredient.fullName}
                    </a>
                  <br />
                  {ingredient.id}
                  <br />
                </label>
              );
            })}
            <button className="grocery-button" onClick={goToGroceryList}>Add to Grocery List</button>

          </p>
          <p className="recipe-body-text">
            Directions
            <br />
            <button className="cooking-button" onClick={togglePopup}> Cooking Mode</button>
            {isOpen && (
              <div className="popup">
                <button className="close-button" onClick={togglePopup}>X</button>
                <div>
                  <p className="popup-text">
                    1. Crack 2 large eggs into a bowl and add a small pinch of salt. Beat eggs until combined<br />
                    <br />
                    2. In an 8-inch nonstick skillet over medium-low heat, melt 1 tbs. unsalted butter.<br />
                    <br />
                    3. Add the eggs to the butter skillet and cook without stirring until the edges begin to set. With a silicone spatula, push the edges toward the center of the pan and tilt the pan so the uncooked eggs move to the edge. Repeat until the eggs are somewhat set but still a little soft in the center, about 6 minutes.<br />
                    <br />
                    4. Place 2 tbs. cheese, 3-4 cherry tomatoes, and 2 tbs. herbs in a line down the center of the omelette and cook for about 1 minute longer, or until the eggs are mostly set but still a little soft in the center.<br />
                    <br />
                    5. Slide the spatula around one side of the omelette at the edge to loosen it. Slip it under the eggs, and use it to carefully fold the omelette in half. Slide the spatula under the folded omelette to loosen it from the pan. Tilt the pan over a plate and use the spatula to nudge it onto the plate. Voila!<br />
                    <br />
                  </p>
                </div>
              </div>

            )}

          </p>
          <p className="recipe-details-text">

            1. Prep the eggs: Crack the eggs into a bowl. Add a small pinch of salt and beat the eggs with a fork until they are well combined.<br />
            <br />
            2. Melt the butter: In an 8-inch nonstick skillet over medium-low heat, melt the butter.<br />
            <br />
            3. Add the eggs and cook the omelette: Add the eggs to the skillet and cook without stirring until the edges begin to set. With a silicone spatula, push the edges toward the center of the pan and tilt the pan so the uncooked eggs move to the edge. Repeat until the eggs are somewhat set but still a little soft in the center, about 6 minutes.<br />
            <br />
            4. Fill the omelette: Place the cheese, tomatoes, and herbs in a line down the center of the omelette and cook for about 1 minute longer, or until the eggs are mostly set but still a little soft in the center.<br />
            <br />
            5. Fold and plate the omelette: Slide the spatula around one side of the omelette at the edge to loosen it. Slip it under the eggs, and use it to carefully fold the omelette in half. Slide the spatula under the folded omelette to loosen it from the pan. Tilt the pan over a plate and use the spatula to nudge it onto the plate. Voila!<br />
            <br />

          </p>
        </div>
      </div>



    </div>

  )
}

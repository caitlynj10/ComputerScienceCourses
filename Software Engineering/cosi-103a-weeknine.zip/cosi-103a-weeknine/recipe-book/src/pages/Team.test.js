import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import Team from './Team';


// test that checks if the team page renders
test('renders team page', () => {
    const { container } = render(<Team />);
    const teamPageElement = screen.getByText(/Caitlyn Jones/i);
    expect(teamPageElement).toBeInTheDocument();
  });
  
  //test that checks if the images in the team page render
  test('renders team images', () => {
    const { container } = render(<Team />);
    const teamImageElement = screen.getByAltText(/Caitlyn Jones/i);
    expect(teamImageElement).toBeInTheDocument();
  });
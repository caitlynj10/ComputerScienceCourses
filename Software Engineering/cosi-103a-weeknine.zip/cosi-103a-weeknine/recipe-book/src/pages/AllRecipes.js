import React, { useState, useEffect } from 'react';
import './recipes.css';
import { fetchAllRecipes, updateIngredientIds } from './recipesAPI';

export default function AllRecipes() {
  const [recipes, setRecipes] = useState([]);

  const deleteRecipe = async (recipeId) => {
    console.log("Trying to delete recipe with ID:", recipeId);  // Log the ID being used for deletion
    if (!recipeId) {
      console.error("Recipe ID is undefined.");
      return;
    }
  
    try {
      const response = await fetch(`/AllRecipes/${recipeId}`, {
        method: 'DELETE',
      });
      if (!response.ok) {
        throw new Error(`Failed to delete recipe with ID ${recipeId}`);
      }
      setRecipes(recipes.filter((recipe) => recipe.id !== recipeId));
    } catch (error) {
      console.error(`Failed to delete recipe:`, error);
    }
  };
  
  useEffect(() => {
    fetchAllRecipes().then(data => {
      console.log("Fetched recipes:", data); // Log to check structure
      setRecipes(data);
    });
  }, []);


  

  useEffect(() => {
    const updateRecipes = async () => {
      const updatedRecipes = await Promise.all(recipes.map(async (recipe) => {
        if (!recipe.ingredients) {
          console.log("No ingredients for recipe:", recipe);
          return recipe; // Return recipe as is if no ingredients
        }

        const updatedIngredients = await updateIngredientIds(recipe.ingredients);
        console.log(updatedIngredients);
        return { ...recipe, ingredients: updatedIngredients };
      }));

      setRecipes(updatedRecipes);
    };
    if (recipes.length > 0) {
      updateRecipes();
    }
  }, [recipes.length]);

  return(
  <div>
    <text className="recipe-pages-header">All Recipes</text>
            {recipes.map((recipe, index) => (
                <div>
            <div className = "all-recipes-card" key={index}>
                <img className="img2" src="https://worldfoodtour.co.uk/wp-content/uploads/2013/06/neptune-placeholder-48.jpg"></img>  
            </div>

            <h2 className = "recipe-card-title">{recipe.name}</h2>
                <details className="details-p">
                        <summary>Recipe Details</summary>
                       <strong>Ingredients</strong><br/>
                       {recipe.ingredients.map((ingredient, i) => (
                        <label key={i}>
                           <a href={`https://fdc.nal.usda.gov/fdc-app.html#/food-details/${ingredient.id}/nutrients`}>
                          {ingredient.name}
                          </a>
                        <br />
                        {ingredient.id}
                        <br />
                </label>
              ))}
                       <br/>
                       <br/>
                       <strong>Directions</strong> <br/>
                       {recipe.instructions}
                </details>
                <button onClick={() => deleteRecipe(recipe.id)}>Delete Recipe</button>
                </div>

            ))}
 </div>
  )
}
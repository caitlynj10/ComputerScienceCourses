import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import GroceryList from './GroceryList';


import { MemoryRouter } from 'react-router-dom'; // Import MemoryRouter

// Mock local storage to test
const localStorageMock = (function() {
    let store = {};
    return {
      getItem(key) {
        return store[key] || null;
      },
      setItem(key, value) {
        store[key] = value.toString();
      },
      clear() {
        store = {};
      },
      removeItem(key) {
        delete store[key];
      },
    };
  })();
  
  Object.defineProperty(window, 'localStorage', { value: localStorageMock });
// Test that checks if the GroceryList component renders
test('renders GroceryList component', () => {
    render(<MemoryRouter> 
    <GroceryList />
  </MemoryRouter>);
    const groceryListComponent = screen.getByTestId('GroceryList');
    expect(groceryListComponent).toBeInTheDocument();
  });


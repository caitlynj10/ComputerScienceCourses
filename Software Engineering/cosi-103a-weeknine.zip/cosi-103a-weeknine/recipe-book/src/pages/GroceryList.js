import React , {useState, useEffect} from 'react';
import {useLocation} from 'react-router-dom';
import './recipes.css';

export default function GroceryList() {
    const [items, setItems] = useState(() => {
        const savedItems = localStorage.getItem('items');
        return savedItems ? JSON.parse(savedItems) : [];
      });

      const location = useLocation();


    useEffect(() => {
      const savedItems = localStorage.getItem('items');
      if (savedItems) {
        setItems(JSON.parse(savedItems));
      }
         }, [location.state]);   

    useEffect(() => {
        localStorage.setItem('items', JSON.stringify(items));
      }, [items]);

    const deleteItem = (itemToDelete) => {
        setItems((prev) => prev.filter((item) => item !== itemToDelete));
      }

      const clearList = () => { 
        setItems([]);
      }

    return (
     
     <div data-testid="GroceryList">
      <text className="grocery-header">
        Grocery List
      <img className="img-style" src='/shopping_cart.png' alt=""></img>
      </text>
    {items.map((item, index) => (
      <div className="item">
    <li key={index}>
      
      <span>{item}</span>
      
      <button className="button-item" onClick={() => deleteItem(item)}>Delete</button>
    </li>
    </div>
    
    ))}
    <button className="button-list" onClick={clearList}>Clear List</button>

    </div>

    );

    }
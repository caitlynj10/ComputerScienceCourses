import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import Enchiladas from './Enchiladas';
import Omelette from './Omelette';
import Pie from './Pie';
import Ramen from './Ramen';
import Salmon from './Salmon';
import Sorbet from './Sorbet';
import TortillaSoup from './TortillaSoup';

// write a function that tests if ingredients is rendered in each page
function testIngredients(page) {
    const { container } = render(
        <BrowserRouter>
            {page}
        </BrowserRouter>
    );
    const ingredientsElement = screen.getByText('Ingredients');
    expect(ingredientsElement).toBeInTheDocument();
}

// write a function that tests if instructions is rendered in each page
function testDirections(page) {
    const { container } = render(
        <BrowserRouter>
            {page}
        </BrowserRouter>
    );
    const instructionsElement = screen.getByText(/Directions/i);
    expect(instructionsElement).toBeInTheDocument();
}

// write a function that tests if image is rendered in each page
function testImage(page) {
    const { container } = render(
        <BrowserRouter>
            {page}
        </BrowserRouter>
    );
    const imageElement = screen.getByAltText(/recipe/i);
    expect(imageElement).toBeInTheDocument();
}

//write a function that tests if cooking mode is rendered in each page
function testCookingMode(page) {
    const { container } = render(
        <BrowserRouter>
            {page}
        </BrowserRouter>
    );
    const cookingModeElement = screen.getByText(/Cooking Mode/i);
    expect(cookingModeElement).toBeInTheDocument();
}

//write a function that tests if when cooking mode button is pressed the cooking mode is rendered
function testCookingModeButton(page) {
    const { container } = render(
        <BrowserRouter>
            {page}
        </BrowserRouter>
    );
    const cookingModeButton = screen.getByText(/Cooking Mode/i);
    fireEvent.click(cookingModeButton);
    const cookingModeElement = container.querySelector('.popup');
    expect(cookingModeElement).toBeInTheDocument();
}

// Define your test for each component
describe('recipes details render', () => {
    const pages = [
        { name: 'Enchiladas', component: <Enchiladas /> },
        { name: 'Omelette', component: <Omelette /> },
        { name: 'Pie', component: <Pie /> },
        { name: 'Ramen', component: <Ramen /> },
        { name: 'Salmon', component: <Salmon /> },
        { name: 'Sorbet', component: <Sorbet /> },
        { name: 'TortillaSoup', component: <TortillaSoup /> },
    ];

    test.each(pages)('%s renders Ingredients', (page) => {
        testIngredients(page.component);
    });

    test.each(pages)('%s renders Instructions', (page) => {
        testDirections(page.component);
    });

    test.each(pages)('%s renders Image', (page) => {
        testImage(page.component);
    });

    test.each(pages)('%s renders Cooking Mode', (page) => {
        testCookingMode(page.component);
    });

    test.each(pages)('%s renders Cooking Mode Button', (page) => {
        testCookingModeButton(page.component);
    });
});

// recipesAPI.js
export const fetchAllRecipes = async () => {
    try {
      const response = await fetch('/AllRecipes');
      if (!response.ok) {
        throw new Error(`API call failed: ${response.status}`);
      }
      const data = await response.json();
      return data;
    } catch (error) {
      console.error(`Failed to fetch recipes:`, error);
      return []; // Return an empty array in case of error
    }
  };
  
  export const updateIngredientIds = async (ingredients) => {
    const apiKey = process.env.REACT_APP_API_KEY;
    const baseUrl = `https://api.nal.usda.gov/fdc/v1/foods/search?api_key=${apiKey}`;
    const updatedIngredients = await Promise.all(ingredients.map(async (ingredient) => {
      const queryUrl = `${baseUrl}&query=${encodeURIComponent(ingredient.name)}`;
      try {
        const response = await fetch(queryUrl);
        if (!response.ok) {
          throw new Error(`API call failed: ${response.status}`);
        }
        const data = await response.json();
        if (data.foods && data.foods.length > 0) {
          const id = data.foods[0].fdcId;
          return { ...ingredient, id }; // Return a new ingredient object with the updated ID
        } else {
          console.log(`No results found for ${ingredient.name}`);
          return ingredient; // Return the original ingredient if no ID is found
        }
      } catch (error) {
        console.error(`Failed to fetch ID for ${ingredient.name}:`, error);
        return ingredient; // Return the original ingredient in case of error
      }
    }));
  
    return updatedIngredients;
  };
  
import React, { useEffect, useState } from 'react';
import './recipes.css';
import { useNavigate } from 'react-router-dom';

export default function Enchiladas() {
  return (
    <>
      <RecipeDetails />
    </>
  );

}


function RecipeDetails() {
  const [checkedItems, setCheckedItems] = useState([]);
  const navigate = useNavigate();

  const handleCheckbox = (event) => {
    const { name, checked } = event.target;

    setIngredients(ingredients =>
      ingredients.map(ingredient =>
        ingredient.name === name ? { ...ingredient, checked: checked } : ingredient
      )
    );

    setCheckedItems((prev) => {
      if (checked) {
        return [...prev, name];
      }
      else {
        return prev.filter((item) => item !== name);
      }
    });
  };

  const goToGroceryList = () => {
    const savedItems = localStorage.getItem('items');
    const allItems = savedItems ? [...JSON.parse(savedItems), ...checkedItems] : checkedItems;
    localStorage.setItem('items', JSON.stringify(allItems));
    navigate('../GroceryList');

  }

  const [isOpen, setIsOpen] = useState(false);
  const togglePopup = () => {
    setIsOpen(!isOpen);
  }

  const [ingredients, setIngredients] = useState([
    { name: "1.5 lb. Tomatillos", fullName: "1 1/2 lb. fresh tomatillos, husks removed and cut into 2-inch pieces", checked: false, id: 0 },
    { name: "White Onion", fullName: "1/2 white onion, peeled and cut into 8 pieces", checked: false, id: 0 },
    { name: "2 Serrano Chilis", fullName: "2 serrano chilis, split into half lengthwise", checked: false, id: 0 },
    { name: "Olive Oil", fullName: "1 tbsp. olive oil", checked: false, id: 0 },
    { name: "2 Garlic Cloves", fullName: "2 garlic cloves", checked: false, id: 0 },
    { name: "Kosher Salt", fullName: "1 1/4 tsp. kosher salt", checked: false, id: 0 },
    { name: "Lime Juice", fullName: "1 tbsp. lime juice", checked: false, id: 0 },
    { name: "Fresh Cilantro", fullName: "1 c. fresh cilantro, leaves and small stems, chopped", checked: false, id: 0 },
    { name: "Chicken Stock", fullName: "1 c. chicken stock", checked: false, id: 0 },
    { name: "Sour Cream", fullName: "1/2 c. sour cream", checked: false, id: 0 },
    { name: "1 Rotisserie Chicken", fullName: "3 c. cooked chicken (from 1 rotisserie chicken)", checked: false, id: 0 },
    { name: "12 oz. Monterey Jack Cheese", fullName: "12 oz. grated Monterey Jack cheese", checked: false, id: 0 },
    { name: "Cumin", fullName: "1 tsp. cumin", checked: false, id: 0 },
    { name: "Chili Powder", fullName: "1 tsp. chili powder", checked: false, id: 0 },
    { name: "Kosher Salt", fullName: "1/2 tsp. kosher salt", checked: false, id: 0 },
    { name: "Ground Black Pepper", fullName: "1/4 tsp. ground black pepper", checked: false, id: 0 },
    { name: "10 8-inch Flour Tortillas", fullName: "10 8-inch flour tortillas", checked: false, id: 0 },
    { name: "Red Onion", fullName: "1/4 c. chopped red onion, optional", checked: false, id: 0 },
    { name: "Fresh Cilantro", fullName: "2 tbsp. chopped, fresh cilantro, optional", checked: false, id: 0 }
  ]);

  useEffect(() => {
    const updateIngredientIds = async () => {
      const apiKey = process.env.REACT_APP_API_KEY; // Moved inside the function for clarity
      console.log(apiKey);
      const updatedIngredients = await Promise.all(ingredients.map(async (ingredient) => {
        const baseUrl = `https://api.nal.usda.gov/fdc/v1/foods/search?api_key=${apiKey}`;
        const queryUrl = `${baseUrl}&query=${encodeURIComponent(ingredient.name)}`;

        try {
          const response = await fetch(queryUrl);
          if (!response.ok) {
            throw new Error(`API call failed: ${response.status}`);
          }
          const data = await response.json();
          if (data.foods && data.foods.length > 0) {
            const id = data.foods[0].fdcId;
            return { ...ingredient, id }; // Return a new ingredient object with the updated ID
          } else {
            console.log(`No results found for ${ingredient.name}`);
            return ingredient; // Return the original ingredient if no ID is found
          }
        } catch (error) {
          console.error(`Failed to fetch ID for ${ingredient.name}:`, error);
          return ingredient; // Return the original ingredient in case of error
        }
      }));

      setIngredients(updatedIngredients); // Update the state once with all updated ingredients
    };

    updateIngredientIds();
    // Removed ingredients from the dependency array to prevent re-triggering
  }, [ingredients]); // Empty array means this effect only runs once after the initial render


  return (
    <div>

      <text className="recipe-text">Enchiladas Verdes</text>
      <p className="details-text">
        Induldge in a savory and spicy enchiladas verdes recipe that is perfect for a family dinner.
      </p>
      <div className='img-container'>
        <img className="img1" src="https://hips.hearstapps.com/hmg-prod/images/enchiladas-verdes-recipe-2-1659537049.jpg?crop=0.6666666666666667xw:1xh;center,top&resize=1200:*" alt="recipe 7" />

      </div>
      <div className='card-container'>
        <div className="card2">
          <p className="recipe-body-text">
            Ingredients
          </p>
          <p className="recipe-details-text">
            <u>FOR THE SAUCE: </u> <br />
            {ingredients.map((ingredient, index) => {
              if (index === 10) {
                return (
                  <>
                    <u>FOR THE ENCHILADAS: </u> <br />
                    <label key={index}>
                      <input type="checkbox" name={ingredient.name} onChange={handleCheckbox} />
                      <a href={`https://fdc.nal.usda.gov/fdc-app.html#/food-details/${ingredient.id}/nutrients`}>
                        {ingredient.fullName}
                      </a>
                      <br />
                      {ingredient.id.toString()}
                      <br /><br />
                    </label>
                  </>
                );
              }
              return (
                <label key={index}>
                  <input type="checkbox" name={ingredient.name} onChange={handleCheckbox} />
                  <a href={`https://fdc.nal.usda.gov/fdc-app.html#/food-details/${ingredient.id}/nutrients`}>
                      {ingredient.fullName}
                    </a>
                  <br />
                  {ingredient.id.toString()}
                  <br /><br />
                </label>
              );
            })}
            <button className="grocery-button" onClick={goToGroceryList}>Add to Grocery List</button>
          </p>
          <p className="recipe-body-text">
            Directions
            <br />
            <button className="cooking-button" onClick={togglePopup}> Cooking Mode</button>
            {isOpen && (
              <div className="popup">
                <button className="close-button" onClick={togglePopup}>X</button>
                <div>
                  <p className="popup-text">
                    1. Preheat the oven to 425°. Place the tomatillos, onion and serrano chilis on a sheet tray lined with foil. Drizzle all over with olive oil and toss to combine. Roast for 25 to 30 minutes until the tomatillos and onions have softened. Let cool slightly then transfer to a blender canister. <br />
                    <br />
                    2.  Add the garlic, salt, lime juice, cilantro, chicken stock, and sour cream to the blender. With the lid vented (to release steam) and a clean kitchen towel covering the opening, blend on high for about 30 seconds, until almost smooth. <br />
                    <br />
                    <u>FOR THE ENCHILADAS: </u><br />
                    3. Meanwhile, combine the chicken, two thirds of the cheese, 3/4 cup of enchilada sauce, cumin, chili powder, salt, and ground black pepper in a large bowl. Stir to combine. <br />
                    <br />
                    4.  Place the tortillas on a microwave-safe plate and cover with a damp paper towel. Microwave for 30 seconds on high to soften. Leave the paper towel over top of them to keep them moist and pliable.  <br />
                    <br />
                    5.  Add 1 cup of the remaining enchilada sauce to a 13-by-9-inch casserole dish and spread to coat the bottom. Place a tortilla flat on a cutting board. Add a mounded 1/3 cup of the chicken mixture in a row in the center of the tortilla and roll up tightly. Place seam side down in the baking dish. Repeat to fill all the tortillas and the casserole dish. Drizzle all over with the remaining sauce and sprinkle with the remaining cheese. <br />
                    <br />
                    6.  Reduce the oven temperature to 375 degrees. Bake for 25 to 30 minutes, until the cheese is melted and the sides are golden and bubbly. Top with onion and cilantro if you like, before serving. <br />
                    <br />
                  </p>
                </div>
              </div>

            )}
          </p>
          <p className="recipe-details-text">
            <u>FOR THE SAUCE: </u> <br />
            1. Preheat the oven to 425°. Place the tomatillos, onion and serrano chilis on a sheet tray lined with foil. Drizzle all over with olive oil and toss to combine. Roast for 25 to 30 minutes until the tomatillos and onions have softened. Let cool slightly then transfer to a blender canister. <br />
            <br />
            2.  Add the garlic, salt, lime juice, cilantro, chicken stock, and sour cream to the blender. With the lid vented (to release steam) and a clean kitchen towel covering the opening, blend on high for about 30 seconds, until almost smooth. <br />
            <br />
            <u>FOR THE ENCHILADAS: </u><br />
            3. Meanwhile, combine the chicken, two thirds of the cheese, 3/4 cup of enchilada sauce, cumin, chili powder, salt, and ground black pepper in a large bowl. Stir to combine. <br />
            <br />
            4.  Place the tortillas on a microwave-safe plate and cover with a damp paper towel. Microwave for 30 seconds on high to soften. Leave the paper towel over top of them to keep them moist and pliable.  <br />
            <br />
            5.  Add 1 cup of the remaining enchilada sauce to a 13-by-9-inch casserole dish and spread to coat the bottom. Place a tortilla flat on a cutting board. Add a mounded 1/3 cup of the chicken mixture in a row in the center of the tortilla and roll up tightly. Place seam side down in the baking dish. Repeat to fill all the tortillas and the casserole dish. Drizzle all over with the remaining sauce and sprinkle with the remaining cheese. <br />
            <br />
            6.  Reduce the oven temperature to 375 degrees. Bake for 25 to 30 minutes, until the cheese is melted and the sides are golden and bubbly. Top with onion and cilantro if you like, before serving. <br />
            <br />

          </p>
        </div>
      </div>

    </div>
  )
}

import React from 'react';
import './Team.css'; // assuming you have your CSS in Team.css

const Team = () => {
  return (
      <div className="team-container">
          <div className='section'>
            <div className="picture">
            <img src='/CaitlynJones.jpg' alt='Caitlyn Jones'></img>
            </div>
            <p><strong>Caitlyn Jones</strong></p>
            Hi! I'm Caitlyn, a sophomore studying Computer Science and<br />
            Applied Math. My favorite recipe on here is the Sesame Garlic<br/>
            Ramen, it's so flavorful and so easy and quick to make!<br />
          </div>

          <div className='section'>
            <div className="picture">
            <img src='/GrantGu.jpg' alt='Grant Gu'></img>
            </div>
            <p><strong>Grant Gu</strong></p>
            Hi! I'm Grant, a senior studying Computer Science. <br />
            My favorite recipe on here is the Omelette, eggs have lots <br/>
            of protein and the recipe is so delicious!<br />
          </div>          
          
          <div className='section'>
            <div className="picture">
              <img src='/JasmineHuang.jpeg' alt='Jasmine Huang'></img>
            </div>
            <p><strong>Jasmine Huang</strong></p>
            Hi! I'm Jasmine, a sophomore studying Computer Science and Business. <br />
            My favorite recipe on here is the Mango Sorbet, Mangoes are my <br/>
            favourite fruit and the recipe is so simple!<br />
          </div>
          
          <div className='section'>
            <div className="picture">
            <img src='/NauriaEO.jpeg' alt='Nauriá E. Oliveira'></img>
            </div>
            <p><strong>Nauriá E. Oliveira</strong></p>
              Hi! I'm Nauriá Emanuely, an undergrad sophomore studying <br />
              Computer Science. My favorite recipe on here is the Butter <br />
              Pan-Seared Salmon, it's so easy to make and tastes amazing!<br />
            </div>
          </div>
  );
};

export default Team;
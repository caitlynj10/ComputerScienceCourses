import React, {useState, useEffect} from 'react';
import './recipes.css';
import {useNavigate} from 'react-router-dom';

export default function Salmon() {
    return (
     <>
    <RecipeDetails/>
    </>
    );
  
    }


  function RecipeDetails(){
    const [checkedItems, setCheckedItems] = useState([]);
      const navigate = useNavigate();

      const handleCheckbox = (event) => {
       const {name, checked} = event.target;

       setIngredients(ingredients =>
        ingredients.map(ingredient =>
          ingredient.name === name ? { ...ingredient, checked: checked } : ingredient
        )
      );

       setCheckedItems((prev) => {
          if(checked){
            return [...prev, name];
          }
          else{
            return prev.filter((item) => item !== name);
          }
        });
      };

      const goToGroceryList = () => {
        const savedItems = localStorage.getItem('items');
        const allItems = savedItems ? [...JSON.parse(savedItems), ...checkedItems] : checkedItems;  
        localStorage.setItem('items', JSON.stringify(allItems));
        navigate('../GroceryList');
      }

      const [isOpen, setIsOpen] = useState(false);
      const togglePopup = () => {
        setIsOpen(!isOpen);
      }

      const [ingredients, setIngredients] = useState([
        {name: "28 oz skinless Salmon filets", fullName: "28 ounces (800 g) skinless salmon filets", checked: false, id: 0},
        {name: "Salt and Pepper", fullName: "Salt and pepper , to season", checked: false, id: 0},
        {name: "Lemon Juice", fullName: "3 tablespoons lemon juice , divided", checked: false, id: 0},
        {name: "Olive Oil", fullName: "1 tablespoon olive oil", checked: false, id: 0},
        {name: "Butter", fullName: "2 tablespoons butter", checked: false, id: 0},
        {name: "8 Garlic Cloves", fullName: "8 cloves garlic , finely chopped or minced", checked: false, id: 0},
        {name: "Fresh Parsley", fullName: "4 tablespoons fresh chopped Italian parsley leaves , divided", checked: false, id: 0},
        {name: "Lemon", fullName: "Lemon slices of half a lemon", checked: false, id: 0},
      ]);
    
      useEffect(() => {
        const updateIngredientIds = async () => {
          const apiKey = process.env.REACT_APP_API_KEY; // Moved inside the function for clarity
          console.log(apiKey);
          const updatedIngredients = await Promise.all(ingredients.map(async (ingredient) => {
            const baseUrl = `https://api.nal.usda.gov/fdc/v1/foods/search?api_key=${apiKey}`;
            const queryUrl = `${baseUrl}&query=${encodeURIComponent(ingredient.name)}`;
    
            try {
              const response = await fetch(queryUrl);
              if (!response.ok) {
                throw new Error(`API call failed: ${response.status}`);
              }
              const data = await response.json();
              if (data.foods && data.foods.length > 0) {
                const id = data.foods[0].fdcId;
                return { ...ingredient, id }; // Return a new ingredient object with the updated ID
              } else {
                console.log(`No results found for ${ingredient.name}`);
                return ingredient; // Return the original ingredient if no ID is found
              }
            } catch (error) {
              console.error(`Failed to fetch ID for ${ingredient.name}:`, error);
              return ingredient; // Return the original ingredient in case of error
            }
          }));
    
          setIngredients(updatedIngredients); // Update the state once with all updated ingredients
        };
    
        updateIngredientIds();
        // Removed ingredients from the dependency array to prevent re-triggering
      }, [ingredients]);

    return(
      <div>
      <text className="recipe-text">Salmon</text>
      <p className="details-text">
      This butter pan-seared salmon is perfect for a quick and easy dinner.
      </p>
      <div className='img-container'>
      <img className="img1" src="https://cafedelites.com/wp-content/uploads/2017/03/Best-Crispy-Lemon-Garlic-Herb-Salmon-IMAGES-5.jpg" alt="Recipe 2"></img>
      </div>
     
      <div className='card-container'>
      <div className="card2">
      <p className="recipe-body-text">
        Ingredients
        </p>
      <p className="recipe-details-text">
      {ingredients.map((ingredient, index) => {
              return (
                <label key={index}>
                  <input type="checkbox" name={ingredient.name} onChange={handleCheckbox} />
                  <a href={`https://fdc.nal.usda.gov/fdc-app.html#/food-details/${ingredient.id}/nutrients`}>
                      {ingredient.fullName}
                    </a>
                  <br />
                  {ingredient.id}
                  <br />
                </label>
              );
            })}
        <button className="grocery-button" onClick={goToGroceryList}>Add to Grocery List</button>
      </p>
      <p className="recipe-body-text">
        Directions
      <br />
      <button className="cooking-button" onClick = {togglePopup}> Cooking Mode</button>
      {isOpen && (
        <div className="popup">
          <button className="close-button" onClick={togglePopup}>X</button>
          <div> 
          <p className="popup-text">
          1. Pat dry room temperature 28 oz skinless salmon filets with paper towel. Season all over with salt, pepper. Squeeze 1-2 teaspoons of lemon juice over each filet, and rub all the flavour in.<br />
          <br />
          2. Heat 1 tbs. olive oil in a large non-stick pan or skillet over medium-high heat until hot. Place salmon filets flesh side down, pressing them lightly so the entire surface of the flesh comes into contact with the pan. Sear, undisturbed, for 3-4 minutes until crispy and golden.<br />
          <br />
          3. Flip and sear the other side of each filet for TWO minutes. Add in 2 tbs. butter, 8 cloves chopped garlic, 3 tablespoons of parsley, remaining lemon juice and lemon slices.  Stir the butter and garlic around each filet.<br />
          <br />
          4. Continue to cook the salmon for a further 1-2 minutes, or until salmon reaches desired doneness. (The butter will begin to brown slightly.) Taste test and season with salt and pepper to your tastes, and add more lemon juice if desired.<br />
          <br />
          5. Garnish with the remaining parsley and drizzle the butter over each filet.<br />
          <br />
          Serve Immediately<br />
          <br />
        </p>
          </div>
        </div>

      )}

      </p>
      <p className="recipe-details-text"> 
        1. Pat dry room temperature salmon filets with paper towel. Season all over with salt, pepper. Squeeze 1-2 teaspoons of lemon juice over each filet, and rub all the flavour in.<br />
          <br />
          2. Heat the olive in a large non-stick pan or skillet over medium-high heat until hot. Place salmon filets flesh side down, pressing them lightly so the entire surface of the flesh comes into contact with the pan. Sear, undisturbed, for 3-4 minutes until crispy and golden.<br />
          <br />
          3. Flip and sear the other side of each filet for TWO minutes. Add in the butter, chopped garlic, 3 tablespoons of parsley, remaining lemon juice and lemon slices.  Stir the butter and garlic around each filet.<br />
          <br />
          4. Continue to cook the salmon for a further 1-2 minutes, or until salmon reaches desired doneness. (The butter will begin to brown slightly.) Taste test and season with salt and pepper to your tastes, and add more lemon juice if desired.<br />
          <br />
          5. Garnish with the remaining parsley and drizzle the butter over each filet.<br />
          <br />
          Serve Immediately<br />
          <br />
      </p>
      </div>
      </div>
      
      </div>
    )
  }

import React, { useState, useEffect} from 'react';
import './recipes.css';
import {useNavigate} from 'react-router-dom';

export default function TortillaSoup() {
    return (
     <>
    
    <RecipeDetails/>
    </>
    );
  
    }


  function RecipeDetails(){
    const [checkedItems, setCheckedItems] = useState([]);
      const navigate = useNavigate();

      const handleCheckbox = (event) => {
       const {name, checked} = event.target;

       setIngredients(ingredients =>
        ingredients.map(ingredient =>
          ingredient.name === name ? { ...ingredient, checked: checked } : ingredient
        )
      );

       setCheckedItems((prev) => {
          if(checked){
            return [...prev, name];
          }
          else{
            return prev.filter((item) => item !== name);
          }
        });
      };
      const goToGroceryList = () => {
        const savedItems = localStorage.getItem('items');
        const allItems = savedItems ? [...JSON.parse(savedItems), ...checkedItems] : checkedItems;  
        localStorage.setItem('items', JSON.stringify(allItems));
        navigate('../GroceryList');

      }

      const [isOpen, setIsOpen] = useState(false);
      const togglePopup = () => {
        setIsOpen(!isOpen);
      } 

      const [ingredients, setIngredients] = useState([
        {name: "Olive Oil", fullName: "1 tablespoon olive oil", checked: false, id: 0},
        {name: "1 Medium Onion", fullName: "1 medium onion, chopped", checked: false, id: 0},
        {name: "3 Garlic Cloves", fullName: "3 cloves garlic, minced", checked: false, id: 0},
        {name: "28 oz Crushed Tomatoes", fullName: "1 (28 ounce) can crushed tomatoes", checked: false, id: 0},
        {name: "10.5 oz Condensed Chicken Broth", fullName: "1 (10.5 ounce) can condensed chicken broth", checked: false, id: 0},
        {name: "Water", fullName: "1 ¼ cups water", checked: false, id: 0},
        {name: "Chili Powder", fullName: "2 teaspoons chili powder", checked: false, id: 0},
        {name: "Dried Oregano", fullName: "1 teaspoon dried oregano", checked: false, id: 0},
        {name: "15 oz Black Beans", fullName: "1 (15 ounce) can black beans, rinsed and drained", checked: false, id: 0},
        {name: "2 Large Chicken Breasts", fullName: "2 large boneless chicken breast halves, cooked and cut into bite-sized pieces", checked: false, id: 0},
        {name: "1 Cup Cooked Corn Kernels", fullName: "1 cup whole corn kernels, cooked", checked: false, id: 0},
        {name: "1 Cup White Hominy", fullName: "1 cup white hominy", checked: false, id: 0},
        {name: "4 oz Green Chile Peppers", fullName: "1 (4 ounce) can chopped green chile peppers", checked: false, id: 0},
        {name: "Fresh Cilantro", fullName: "¼ cup chopped fresh cilantro", checked: false, id: 0},
        {name: "Crushed Tortilla Chips", fullName: "½ cup crushed tortilla chips, or to taste", checked: false, id: 0},
        {name: "2 Medium Avocados", fullName: "2 medium avocados, sliced, or to taste", checked: false, id: 0},
        {name: "Monterey Jack Cheese", fullName: "½ cup shredded Monterey Jack cheese, or to taste", checked: false, id: 0},
        {name: "Green Onions", fullName: "2 tablespoons chopped green onions, or to taste", checked: false, id: 0}
      ]);
    
      useEffect(() => {
        const updateIngredientIds = async () => {
          const apiKey = process.env.REACT_APP_API_KEY; // Moved inside the function for clarity
          console.log(apiKey);
          const updatedIngredients = await Promise.all(ingredients.map(async (ingredient) => {
            const baseUrl = `https://api.nal.usda.gov/fdc/v1/foods/search?api_key=${apiKey}`;
            const queryUrl = `${baseUrl}&query=${encodeURIComponent(ingredient.name)}`;
    
            try {
              const response = await fetch(queryUrl);
              if (!response.ok) {
                throw new Error(`API call failed: ${response.status}`);
              }
              const data = await response.json();
              if (data.foods && data.foods.length > 0) {
                const id = data.foods[0].fdcId;
                return { ...ingredient, id }; // Return a new ingredient object with the updated ID
              } else {
                console.log(`No results found for ${ingredient.name}`);
                return ingredient; // Return the original ingredient if no ID is found
              }
            } catch (error) {
              console.error(`Failed to fetch ID for ${ingredient.name}:`, error);
              return ingredient; // Return the original ingredient in case of error
            }
          }));
    
          setIngredients(updatedIngredients); // Update the state once with all updated ingredients
        };
    
        updateIngredientIds();
        // Removed ingredients from the dependency array to prevent re-triggering
      }, [ingredients]);

    return(
      <div>
       
        <text className="recipe-text">Chicken Tortilla Soup</text>
        <div className='img-container'>
        <img className="img1" src="https://www.jerseygirlcooks.com/wp-content/uploads/2010/03/tortilla-soup-FB.jpg " alt="recipe 6"/>
        </div>
        
      <p className="details-text">
      Induldge in a savory and spicy chicken tortilla soup recipe that is perfect for a family dinner.
      </p>
      <div className='card-container'>
      <div className="card2">
      <p className="recipe-body-text">
        Ingredients
        </p>
      <p className="recipe-details-text">
      {ingredients.map((ingredient, index) => {
              return (
                <label key={index}>
                  <input type="checkbox" name={ingredient.name} onChange={handleCheckbox} />
                  <a href={`https://fdc.nal.usda.gov/fdc-app.html#/food-details/${ingredient.id}/nutrients`}>
                      {ingredient.fullName}
                    </a>
                  <br />
                  {ingredient.id}
                  <br />
                </label>
              );
            })}
        <button className="grocery-button" onClick={goToGroceryList}>Add to Grocery List</button>

      </p>
      <p className="recipe-body-text">
        Directions
        <br />  
        <button className="cooking-button" onClick = {togglePopup}> Cooking Mode</button>
      {isOpen && (
        <div className="popup">
          <button className="close-button" onClick={togglePopup}>X</button>
          <div> 
          <p className="popup-text">
          1.  Heat oil in a stockpot over medium heat. Add onion and garlic; sauté until soft, about 5 minutes. Stir in chili powder and oregano. <br />
          <br />
          2.  Stir in crushed tomatoes, condensed broth, and water; bring to a boil. Reduce heat and simmer for 5 to 10 minutes. <br />  
          <br />
          3.  Stir in black beans, corn, hominy, chile peppers, and cilantro. Simmer for 10 minutes. <br />
          <br />
          4.  Ladle soup into individual serving bowls, and top with crushed tortilla chips, avocado slices, cheese, and chopped green onion. <br />
          <br />
          </p>
          </div>
        </div>

      )}
      </p>
      <p className="recipe-details-text">
      1.  Heat oil in a stockpot over medium heat. Add onion and garlic; sauté until soft, about 5 minutes. Stir in chili powder and oregano. <br />
          <br />
          2.  Stir in crushed tomatoes, condensed broth, and water; bring to a boil. Reduce heat and simmer for 5 to 10 minutes. <br />  
          <br />
          3.  Stir in black beans, corn, hominy, chile peppers, and cilantro. Simmer for 10 minutes. <br />
          <br />
          4.  Ladle soup into individual serving bowls, and top with crushed tortilla chips, avocado slices, cheese, and chopped green onion. <br />
        <br />
      </p>
      </div>
      </div>
     
      </div>
    )
  }

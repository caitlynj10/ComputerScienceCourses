import React, { useState } from 'react';
import './recipes.css';

export default function SubmitRecipes(){
  const [recipeName, setRecipeName] = useState('');
  const [recipeIngredients, setRecipeIngredients] = useState('');
  const [recipeInstructions, setRecipeInstructions] = useState('');

  const addIngredient = () =>{
    setRecipeIngredients([...recipeIngredients, '' ]);
  }

  const updateIngredient = (index, value) => {
    const newIngredients = [...recipeIngredients];
    newIngredients[index] = value;
    setRecipeIngredients(newIngredients);
  }
  const handleSubmit = (event) => {
    event.preventDefault();

    fetch('/SubmitRecipes', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: recipeName,
        ingredients: recipeIngredients,
        instructions: recipeInstructions,
      }),
    })
    .then(response => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
    }
     return response.json();
  })
    .then(data => {
      console.log('Success:', data);
      setRecipeName('');
      setRecipeIngredients('');
      setRecipeInstructions('');
    })
    .catch((error) => {
      console.error('Error:', error);
    });
  }

  



  return(
    <>
    <div>
        <text className="recipe-pages-header">Submit Recipes</text>
        <div className="recipe-form-container">
        <form onSubmit={handleSubmit}>
          <div>
            <label for="recipeName">Recipe Name:</label>
            <input type="text" id="recipeName" name="recipeName" value={recipeName} onChange={(event) => setRecipeName(event.target.value)} />
          </div>
          <div>
            <label for="ingredients">Ingredients:</label>
            <textarea id="ingredients" name="ingredients" value={recipeIngredients} onChange={(event) => setRecipeIngredients(event.target.value)} />
          </div>
          <div>
            <label for="instructions">Instructions:</label>
            <textarea id="instructions" name="instructions" value={recipeInstructions} onChange={(event) => setRecipeInstructions(event.target.value)} />
          </div>
          <div>
            <button type="submit">Submit</button>
          </div>
        </form>
        </div>
        </div>

    </>
  )
  
}

import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import SubmitRecipes from './SubmitRecipes';

// test that checks if the submit recipes page renders
test('renders submit recipes page', () => {
    const { container } = render(<SubmitRecipes />);
    const submitRecipesPageElement = screen.getByText(/Submit Recipes/i);
    expect(submitRecipesPageElement).toBeInTheDocument();
  });

  //test that checks if the form in the submit recipes page renders
  test('renders submit recipes form', () => {
    const { container } = render(<SubmitRecipes />);
    const submitRecipesFormElement = screen.getByText(/Recipe Name:/i);
    expect(submitRecipesFormElement).toBeInTheDocument();
  });

  //test that checks if the submit button in the submit recipes page renders
  test('renders submit button', () => {
    const { container } = render(<SubmitRecipes />);
    const submitButtonElement = screen.getByText('Submit');
    expect(submitButtonElement).toBeInTheDocument();
  });

  //test that checks if the input for the recipe name in the submit recipes page renders
  test('renders recipe name input', () => {
    const { container } = render(<SubmitRecipes />);
    const recipeNameInputElement = screen.getByText(/Recipe Name:/i);
    expect(recipeNameInputElement).toBeInTheDocument();
  });

  //test that checks if the input for the ingredients in the submit recipes page renders
  test('renders ingredients input', () => {
    const { container } = render(<SubmitRecipes />);
    const ingredientsInputElement = screen.getByText(/Ingredients:/i);
    expect(ingredientsInputElement).toBeInTheDocument();
  });

  //test that checks if the input for the instructions in the submit recipes page renders
  test('renders instructions input', () => {
    const { container } = render(<SubmitRecipes />);
    const instructionsInputElement = screen.getByText(/Instructions:/i);
    expect(instructionsInputElement).toBeInTheDocument();
  });

  //test that checks if when inputting a name in the recipe name input, the value is stored
    test('input recipe name', () => {
        const { container } = render(<SubmitRecipes />);
        const recipeNameInputElement = screen.getByLabelText(/Recipe Name:/i);
        fireEvent.change(recipeNameInputElement, { target: { value: 'test' } });
        expect(recipeNameInputElement.value).toBe('test');
    });

    //test that checks if when inputting ingredients in the ingredients input, the value is stored
    test('input ingredients', () => {
        const { container } = render(<SubmitRecipes />);
        const ingredientsInputElement = screen.getByLabelText(/Ingredients:/i);
        fireEvent.change(ingredientsInputElement, { target: { value: 'test' } });
        expect(ingredientsInputElement.value).toBe('test');
    });

    //test that checks if when inputting instructions in the instructions input, the value is stored
    test('input instructions', () => {
        const { container } = render(<SubmitRecipes />);
        const instructionsInputElement = screen.getByLabelText(/Instructions:/i);
        fireEvent.change(instructionsInputElement, { target: { value: 'test' } });
        expect(instructionsInputElement.value).toBe('test');
    });
    
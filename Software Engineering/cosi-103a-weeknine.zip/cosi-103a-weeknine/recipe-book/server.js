const express = require('express');
const path = require('path');
const app = express();
const port = process.env.PORT || 5000;

// Serve static files from the React app build output directory
app.use(express.static(path.join(__dirname, 'build')));

// Parse JSON bodies (as sent by API clients)
app.use(express.json());

let recipes = [];
let currentId = 1; // Initialize a counter to assign unique IDs to recipes

// Endpoint to retrieve all recipes
app.get('/AllRecipes', (req, res) => {
  res.json(recipes);
});

// Endpoint to add a new recipe
app.post('/SubmitRecipes', (req, res) => {
  const newRecipe = {
    id: currentId++, // Assign an incremental ID
    ...req.body
  };
  let ingredients = newRecipe.ingredients.split('\n');
  newRecipe.ingredients = ingredients.map(ingredient => {
    return {
      name: ingredient,
      fullName: ingredient,
      checked: false,
      id: 0  // Assuming unique IDs are not required for ingredients
    }
  });
  recipes.push(newRecipe);
  res.json(newRecipe);
});

// Endpoint to delete a recipe
app.delete('/AllRecipes/:id', (req, res) => {
  const { id } = req.params;
  recipes = recipes.filter(recipe => recipe.id !== parseInt(id));
  res.status(200).send({ message: "Recipe deleted successfully." });
});

// The "catchall" handler: for any request that doesn't match one above, send back React's index.html file.
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'build', 'index.html'));
});

app.listen(port, () => {
  console.log(`Server is listening on port ${port}`);
});

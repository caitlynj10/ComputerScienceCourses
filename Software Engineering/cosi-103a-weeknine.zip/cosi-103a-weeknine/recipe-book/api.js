// api.js
const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();

// Middleware to parse JSON bodies
app.use(express.json());

// Serve static files from the React app
app.use(express.static(path.join(__dirname, 'client/build')));

let recipes = []; // Initial list of recipes

// Endpoint to get list of recipes
app.get('http://localhost:5000/AllRecipes', (req, res) => {
  res.json(recipes);
});

// Endpoint to add a new recipe
app.post('http://localhost:5000/SubmitRecipes', (req, res) => {
  const newRecipe = req.body;
  console.log('Adding new recipe: ', newRecipe);
  recipes.push(newRecipe);
  // res.json(newRecipe);
  res.json({status: 'success'});
});

// Handles any requests that don't match the ones above
app.get('*', (req,res) =>{
  res.sendFile(path.join(__dirname+'/client/build/index.html'));
});

const port = process.env.PORT || 5000;
app.listen(port);

console.log('App is listening on port ' + port);
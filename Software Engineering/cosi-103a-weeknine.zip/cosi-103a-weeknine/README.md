# cosi-103a
Caitlyn Jones caitlynj@brandeis.edu
Jasmine Huang jasminehuang@brandeis.edu
Nauriá E. Oliveira nauriaeoliveira@brandeis.edu
Grant Gu zhongshugu@brandeis.edu

Welcome to our Recipe Book app! This website was collaboratively made by the four of us. It contains 6 recipes taken from online. You can view each individual recipe by clicking on the title and image cards in the home landing page. You can also see pictures and small bios of each team member in the team members page.

Here is how to start this react application:
1. download the project
2. open it in vscode or another IDE
3. change directory into recipe-book (cd recipe-book)
4. run 'npm install' in terminal to download dependencies and other files needed to run the application
5. run 'npm run build' in the terminal
6. run “npm start” in the terminal to start the application
7. if the browser doesn't automatically open up, or there isn't an option for you to click it open from vscode, type 'localhost:5000' into your browser

What our tests test:
1. if the website renders
2. if the title renders
3. if the navigation bar renders
4. if the images in the recipe cards render
5. if clicking on the recipe cards titles leads to the recipe page rendering
6. if the images in the team page render
7. if the team page renders
8. if the cooking mode button renders
9. if the cooking mode screen renders
10. if the grocery list works
12. if the submit recipe page renders
13. if each of the submit recipe page buttons render
14. if each of the submit recipe page values can be inputted and submitted and the value will be stored

Our project has 3 Azure alerts:
1. on requests to our website to ensure there aren't too any requests being made. The threshold is more than 100 requests.
2. on CPU usage. The threshold is more than 90 cores.
3. on memory space. the threshold is more than 95 bytes.
